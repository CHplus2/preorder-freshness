# Optional poster text

## Introduction

Home-based food entrepreneurs need to organise advance orders, ingredient records and sales information. The project’s literature and platform review identified limited support for flexible preordering, recorded ingredient shelf life and independent business branding. A web application was developed and refined for Wrap & Bowl Kuch in Kuching, Sarawak.

## Problem statement

Preorder details can be scattered across messages. Ingredient date and storage records may sit outside the ordering process. Reviewed platforms offer limited control over date-based ordering and an individual business’s identity. The project brings these records and customer choices into one application.

## Scope

Customers can browse menus, request date/quantity/budget suggestions, review their basket and place an eligible preorder. The kitchen owner manages menus, ingredients, stock batches, packaging, delivery-area fees, orders, payment evidence and sales reports. Banking evidence is reviewed manually; there is no live courier API integration.

## Methodology / development approach

The project reviewed relevant literature and existing platforms, gathered client requirements, and developed the application in stages. Client feedback guided changes such as packaging stock, area-based fees, morning handover, receipt uploads and simpler order-received states. Functional and browser checks examined valid and invalid inputs. Formal client and student evaluation remains planned.

## Brief literature context

Pallianysamy et al. (2025) discuss food safety in Malaysian home-based food businesses. Eu and Sameeha (2021) examine healthy-food availability and food choices among Malaysian public-university students using food-delivery applications. FoodSafety.gov provides general cold-storage guidance that owners can consult when documenting storage life. These sources motivate the project; they do not validate this application or prove that a batch is physically safe.

## Implemented system

The implemented system connects a branded menu, customer preorders, ingredient/packaging records and owner reporting. Eligible stock is checked for the selected date and deducted when an order is placed. The owner records ingredient date evidence and reviews private payment proof separately from confirming food receipt. Sales and optional menu recommendations support the wider project objectives.

## Testing and results available now

Functional checks cover selected account, date, stock, packaging, payment-evidence and reporting rules. In one captured local order test, recorded chicken stock decreased by 130 g and salad-bowl stock decreased by one piece. The test used a separate example database. Formal client acceptance and student survey results are not yet available; no satisfaction score or paid conversion improvement is claimed.

## User evaluation — update later

Use this section only after genuine responses are collected. State who participated, the number of responses, tasks attempted, the questions or measures used, actual findings and any resulting changes. Report untried tasks separately. Do not describe a functional test as a student survey or client acceptance result.

## Conclusion and limitations

The prototype connects preorders, recorded storage life, storefront identity, sales information and menu suggestions for one home-based business. Functional evidence supports the tested rules; formal user evaluation remains to be completed. Dates support planning but do not detect contamination or guarantee food safety. Customer coordination and courier delivery still depend on the business’s actual operations.

## Selected references

Pallianysamy, S., Abdul-Mutalib, N. A., Abidin, U. F. U. Z., Rashid, N. K. M., & Ahmad, N. H. (2025). Home-based Foods in Malaysia: A Food Safety Perspective. Pertanika Journal of Tropical Agricultural Science, 48(3).

Eu, E. Z. R., & Sameeha, M. J. (2021). Consumers’ perceptions of healthy food availability in online food delivery applications and its association with food choices among public university students in Malaysia. Frontiers in Nutrition, 8, 674427. https://doi.org/10.3389/fnut.2021.674427

FoodSafety.gov. (n.d.). Cold food storage chart. https://www.foodsafety.gov/food-safety-charts/cold-food-storage-charts