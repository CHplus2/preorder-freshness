# Choosing diagrams

These are the current report diagrams, supplied as optional material rather than mandatory poster requirements.

- uc-customer / uc-owner: customer and owner use cases.
- class-domain: the core conceptual class model; it is not every database field.
- sequence-placement: detailed order-placement sequence.
- activity-checkout: checkout workflow with decisions.
- architecture-current: main application components.
- erd-orders / erd-ingredients / erd-packaging: relevant database relationships.

Use PNG for a straightforward insert, SVG for a scalable image, or .drawio for editing in diagrams.net. Match any later required diagram to the one in your report. Prefer one legible diagram to a collection of unreadable thumbnails. Editing these files needs no Codex subscription. Review any content changes against the actual system.
