from pathlib import Path
import json,xml.etree.ElementTree as ET,hashlib
from PIL import Image
W=Path(__file__).resolve().parent;F=W/'figures';sources=json.loads((W/'diagram-source.json').read_text());rows=[]
def crosses(a,b,box):
 x,y,w,h=box
 return (a[0]==b[0] and x+1<a[0]<x+w-1 and max(min(a[1],b[1]),y+1)<min(max(a[1],b[1]),y+h-1)) or (a[1]==b[1] and y+1<a[1]<y+h-1 and max(min(a[0],b[0]),x+1)<min(max(a[0],b[0]),x+w-1))
for source in sources:
 n=source['args'][0];m=json.loads((F/(n+'.json')).read_text());assert m['semantic_source']==source
 assert m['font']=='Times New Roman'
 vertices=ET.parse(F/(n+'.drawio')).findall('.//mxCell[@vertex="1"]');edges=ET.parse(F/(n+'.drawio')).findall('.//mxCell[@edge="1"]')
 assert len(vertices)>len(m['nodes']) and len(edges)==len(m['connectors'])
 for e in m['connectors']:
  if e['orthogonal']:assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(e['points'],e['points'][1:])),n
  if n.startswith(('erd','class','activity','architecture')):
   for a,b in zip(e['points'],e['points'][1:]):
    for k,v in m['nodes'].items():
     if k in [e['source'],e['target']] or v['shape'] not in ['rect','action','cylinder']:continue
     assert not crosses(a,b,v['box']),(n,k,e)
  assert all(0<=p[0]<=m['canvas'][0] and 0<=p[1]<=m['canvas'][1] for p in e['points'])
 if n.startswith('sequence'):
  original=[e for e in source['args'][2] if e[0] not in ['frame','end','note']]
  messages=[e for e in m['connectors'] if not e['semantic_label'].startswith('Lifeline:')]
  assert [e['semantic_label'] for e in messages]==[e[2] for e in original]
  assert all(e['dashed']==(len(original[i])>3) for i,e in enumerate(messages))
 assert '<polyline' in (F/(n+'.svg')).read_text()
 im=Image.open(F/(n+'.png'));assert im.width==2*m['canvas'][0]
 rows.append({'diagram':n,'editable_vertices':len(vertices),'editable_connectors':len(edges),'axis_aligned_required_connectors':True,'source_semantics_preserved':True,'image_pixels':list(im.size)})
# Prior screenshots, original figures and model plot are deliberately outside this redraw.
result={'status':'passed','technical_diagrams':len(rows),'diagrams':rows,'rendering':'Inkscape SVG marker/dash support; 2x PNG; native editable draw.io','scope':'Diagram presentation only; original semantic definitions retained in full'}
(W/'evidence/diagram-quality.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':'passed','diagrams':len(rows),'vertices':sum(r['editable_vertices'] for r in rows),'connectors':sum(r['editable_connectors'] for r in rows)}))
