FYP report revision — Christopher Hansen, 2402081406

Open FYP2_Christopher_2402081406_Updated.docx as the editable master.
The PDF is the rendered preview; the Word fields may repaginate on another machine.
Read Revision_and_Submission_Notes before submission. Objectives are unchanged.
Actual participant results, institutional signatures and similarity reports have not been invented.

figures/: the 41 embedded figure assets and supporting editable SVG/DOT/sequence JSON sources.
  SVG can be edited in a vector editor. DOT uses Graphviz; sequence JSON records actors/messages.
report_text/: editable chapter text and structured scenarios/data dictionary.
evidence/: isolated command logs, manifest and document-quality checks at Git ab1a976.
  806 SQLite application checks + 23 separate PostgreSQL checks = all 829 discovered checks exercised.
  External provider responses were mocked/local; these are not production/UAT outcome claims.

The original uploaded report, senior example and university briefing are not duplicated.
No private production database, credentials or trained model/data bundle is included.
The original Genpact archive remains a separate GitHub Release backup.
Website source and production data were not changed by preparing this report.
