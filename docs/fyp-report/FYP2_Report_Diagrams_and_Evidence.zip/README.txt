FYP report revision — Christopher Hansen, 2402081406

Open FYP2_Christopher_2402081406_Updated.docx as the editable master.
The PDF is the rendered preview; Word may repaginate on another machine.
Read Revision_and_Submission_Notes before submission. Objectives are unchanged.
Participant results, institutional signatures and similarity reports have not been invented.

Font correction: Word document defaults, paragraph/character styles, themes, tables,
headings, fields, contents lists and footers explicitly use Times New Roman.
Theme overrides have been removed. Original images, website screenshots and authored
diagrams preserve their own fonts. The local PDF uses the documented Liberation Serif
substitute where Microsoft Times New Roman is unavailable.

figures/: the 41 embedded figure assets and editable SVG/DOT/sequence JSON sources.
report_text/: chapter text and structured scenarios/data dictionary.
report_tools/: the font consistency repair used on Word files.
evidence/: isolated command logs, manifest, font and document-quality checks.
  806 SQLite checks + 23 separate PostgreSQL checks = all 829 application checks exercised.
  Provider responses were mocked/local; these are not production or UAT outcome claims.

No private production database, credentials or trained model/data bundle is included.
The original Genpact archive remains a separate GitHub Release backup.
