"""Grid-aligned technical diagrams with explicit, non-curved connectors.
Exports a vector SVG, print PNG, editable diagrams.net XML and semantic JSON.
"""
from pathlib import Path
from collections import Counter
import html,json,textwrap,math,heapq,subprocess,os
from xml.etree.ElementTree import Element,SubElement,tostring
from PIL import ImageFont

FONT='Times New Roman';INK='#1a1a1a'
_REG=ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf',24)
_BOLD=ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf',24)

def measure(s,size=24,bold=False):return (_BOLD if bold else _REG).getlength(s)*size/24

def wrap(s,width,size=24,bold=False):
 result=[]
 for part in s.split('\n'):
  words=part.split();line=''
  for word in words:
   trial=(line+' '+word).strip()
   if line and measure(trial,size,bold)>width:result.append(line);line=word
   else:line=trial
  result.append(line)
 return result

def overlaps(a,b,pad=0):return a[0]<b[0]+b[2]+pad and a[0]+a[2]>b[0]-pad and a[1]<b[1]+b[3]+pad and a[1]+a[3]>b[1]-pad

def simplify(points):
 out=[]
 for p in points:
  p=tuple(round(v,2) for v in p)
  if out and p==out[-1]:continue
  if len(out)>1 and ((out[-2][0]==out[-1][0]==p[0]) or (out[-2][1]==out[-1][1]==p[1])):out[-1]=p
  else:out.append(p)
 return out

class Canvas:
 def __init__(self,name,w,h,title):
  self.name=name;self.w=w;self.h=h;self.title=title;self.back=[];self.wires=[];self.shapes=[];self.labels=[];self.nodes={};self.edges=[];self.cells=[];self.label_boxes=[];self.count=0
 def text(self,x,y,value,size=24,width=None,anchor='middle',bold=False,italic=False,background=False,export=True):
  lines=wrap(value,width or 10000,size,bold);lineh=round(size*1.18,2);ww=max((measure(s,size,bold) for s in lines),default=0)
  xx=x-ww/2 if anchor=='middle' else x if anchor=='start' else x-ww
  box=(xx,y,ww,len(lines)*lineh)
  if background:self.labels.append(f'<rect x="{xx-5}" y="{y-2}" width="{ww+10}" height="{box[3]+4}" fill="white"/>')
  for i,line in enumerate(lines):
   self.labels.append(f'<text x="{x}" y="{y+i*lineh+size*.82}" font-family="{FONT}" font-size="{size}" text-anchor="{anchor}" font-weight="{"bold" if bold else "normal"}" font-style="{"italic" if italic else "normal"}" fill="{INK}">{html.escape(line)}</text>')
  self.label_boxes.append(box)
  if export:
   self.count+=1;self.cells.append(dict(id=f'label{self.count}',box=(xx,y,max(ww,4),box[3]),value='<br>'.join(html.escape(s) for s in lines),style=f'text;html=1;strokeColor=none;fillColor={"#ffffff" if background else "none"};align=left;verticalAlign=top;fontFamily={FONT};fontSize={size};fontStyle={int(bold)+2*int(italic)};spacing=0;'))
  return box
 def frame(self,box,title=None):
  x,y,w,h=box;self.back.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="white" stroke="{INK}" stroke-width="1.7"/>')
  self.count+=1;self.cells.append(dict(id=f'frame{self.count}',box=box,value='',style='shape=rectangle;fillColor=#ffffff;strokeColor=#1a1a1a;strokeWidth=1.7;'))
  if title:self.text(x+w/2,y+13,title,size=27,bold=True)
 def node(self,id,box,label='',shape='rect',size=24,fill='white',bold=False):
  assert id not in self.nodes,id
  self.nodes[id]=dict(box=tuple(box),shape=shape,label=label);x,y,w,h=box;style='shape=rectangle;'
  if shape=='ellipse':
   self.shapes.append(f'<ellipse cx="{x+w/2}" cy="{y+h/2}" rx="{w/2}" ry="{h/2}" fill="{fill}" stroke="{INK}" stroke-width="1.7"/>');style='shape=ellipse;'
  elif shape in ['initial','final']:
   self.shapes.append(f'<circle cx="{x+w/2}" cy="{y+h/2}" r="{w/2}" fill="{"black" if shape=="initial" else "white"}" stroke="black" stroke-width="1.8"/>')
   if shape=='final':self.shapes.append(f'<circle cx="{x+w/2}" cy="{y+h/2}" r="{w/2-7}" fill="black"/>')
   style='shape=ellipse;fillColor=#000000;' if shape=='initial' else 'shape=doubleEllipse;fillColor=#ffffff;'
  elif shape in ['diamond','merge']:
   self.shapes.append(f'<polygon points="{x+w/2},{y} {x+w},{y+h/2} {x+w/2},{y+h} {x},{y+h/2}" fill="{fill}" stroke="{INK}" stroke-width="1.7"/>');style='shape=rhombus;'
  elif shape=='actor':
   cx=x+w/2;cy=y+14
   self.shapes.append(f'<circle cx="{cx}" cy="{cy}" r="13" fill="white" stroke="{INK}" stroke-width="1.7"/><path d="M{cx},{cy+13} V{cy+58} M{cx-26},{cy+32} H{cx+26} M{cx},{cy+58} L{cx-23},{cy+88} M{cx},{cy+58} L{cx+23},{cy+88}" fill="none" stroke="{INK}" stroke-width="1.7"/>')
   style='shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;'
  elif shape=='note':
   self.shapes.append(f'<path d="M{x},{y} H{x+w-18} L{x+w},{y+18} V{y+h} H{x} Z M{x+w-18},{y} V{y+18} H{x+w}" fill="white" stroke="{INK}" stroke-width="1.7"/>');style='shape=note;size=18;'
  elif shape=='cylinder':
   self.shapes.append(f'<path d="M{x},{y+18} C{x},{y-6} {x+w},{y-6} {x+w},{y+18} V{y+h-18} C{x+w},{y+h+6} {x},{y+h+6} {x},{y+h-18} Z M{x},{y+18} C{x},{y+42} {x+w},{y+42} {x+w},{y+18}" fill="{fill}" stroke="{INK}" stroke-width="1.7"/>');style='shape=cylinder3;boundedLbl=1;'
  else:
   rr=15 if shape=='action' else 0
   self.shapes.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rr}" fill="{fill}" stroke="{INK}" stroke-width="1.7"/>')
   style='rounded=1;arcSize=12;' if shape=='action' else 'shape=rectangle;'
  if label:
   if shape!='actor':
    while size>20 and len(wrap(label,w-26 if shape!='diamond' else w*.67,size,bold))*size*1.18>h-18:size-=1
   lines=wrap(label,w-26 if shape!='diamond' else w*.67,size,bold);hh=len(lines)*size*1.18
   if shape=='actor':self.text(x+w/2,y+h+10,label,size=size,width=180,bold=bold,export=False)
   else:self.text(x+w/2,y+(h-hh)/2,label,size=size,width=w-26 if shape!='diamond' else w*.67,bold=bold,export=False)
  self.cells.append(dict(id=id,box=box,value=html.escape(label).replace('\n','<br>'),style=style+f'whiteSpace=wrap;html=1;fillColor={"#000000" if shape=="initial" else fill};strokeColor={INK};strokeWidth=1.7;fontFamily={FONT};fontSize={size};fontStyle={int(bold)};'))
 def card(self,id,x,y,w,title,fields,methods=None,size=25):
  lines=[a for row in fields for a in wrap(row,w-24,size)];ml=[a for row in (methods or []) for a in wrap(row,w-24,size)]
  head=46 if '\n' not in title else 72;body=len(lines)*30+18;mh=len(ml)*30+18 if ml else 0;h=head+body+mh
  self.node(id,(x,y,w,h));self.shapes.append(f'<rect x="{x}" y="{y}" width="{w}" height="{head}" fill="#f2f2f2" stroke="{INK}" stroke-width="1.7"/>')
  self.text(x+w/2,y+9,title,size=26,width=w-20,bold=True,export=False)
  for i,line in enumerate(lines):self.text(x+12,y+head+9+i*30,line,size=size,anchor='start',export=False)
  if ml:
   yy=y+head+body;self.shapes.append(f'<line x1="{x}" y1="{yy}" x2="{x+w}" y2="{yy}" stroke="{INK}" stroke-width="1.5"/>')
   for i,line in enumerate(ml):self.text(x+12,yy+9+i*30,line,size=size,anchor='start',export=False)
  value='<div style="text-align:center"><b>'+html.escape(title).replace('\n','<br>')+'</b></div><hr>'+ '<br>'.join(html.escape(s) for s in lines)
  if ml:value+='<hr>'+'<br>'.join(html.escape(s) for s in ml)
  cell=next(z for z in self.cells if z['id']==id);cell['value']=value;cell['style']+=f'align=left;verticalAlign=top;spacing=9;fontSize={size};'
  self.nodes[id].update(label=title,fields=fields,methods=methods or [])
  return h
 def edge(self,points,source=None,target=None,arrow='filled',dashed=False,label=None,label_at=None,size=21,full=None,orthogonal=True):
  points=simplify(points);assert len(points)>=2
  if orthogonal:assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(points,points[1:])),(self.name,points)
  pts=' '.join(f'{x},{y}' for x,y in points);marker='' if arrow=='none' else f' marker-end="url(#{"open" if arrow=="open" else "filled"})"'
  dash=' stroke-dasharray="8 5"' if dashed else ''
  self.wires.append(f'<polyline points="{pts}" fill="none" stroke="{INK}" stroke-width="1.65" stroke-linejoin="miter"{marker}{dash}><title>{html.escape(full or label or "association")}</title></polyline>')
  e=dict(points=points,source=source,target=target,arrow=arrow,dashed=dashed,label=label or '',semantic_label=full or label or '',orthogonal=orthogonal);self.edges.append(e)
  if label and label_at:self.text(*label_at,label,size=size,background=True,width=280)
 def anchor(self,id,side,fraction=.5):
  x,y,w,h=self.nodes[id]['box'];return {'L':(x,y+h*fraction),'R':(x+w,y+h*fraction),'T':(x+w*fraction,y),'B':(x+w*fraction,y+h)}[side]
 def save(self,folder,semantic=None):
  folder=Path(folder);folder.mkdir(exist_ok=True,parents=True)
  defs=f'<defs><marker id="filled" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto"><polygon points="0,0 9,5 0,10" fill="{INK}"/></marker><marker id="open" markerWidth="11" markerHeight="11" refX="10" refY="5" orient="auto"><polyline points="0,0 10,5 0,10" fill="none" stroke="{INK}" stroke-width="1.5"/></marker></defs>'
  svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}"><title>{html.escape(self.title)}</title><rect width="100%" height="100%" fill="white"/>'+defs+''.join(self.back+self.wires+self.shapes+self.labels)+'</svg>'
  (folder/(self.name+'.svg')).write_text(svg)
  # Inkscape honours SVG dash patterns and marker arrowheads; MuPDF's SVG subset does not.
  env=dict(os.environ,XDG_CONFIG_HOME='/tmp/fyp-inkscape-config',XDG_CACHE_HOME='/tmp/fyp-inkscape-cache')
  subprocess.run(['inkscape',str(folder/(self.name+'.svg')),'--export-type=png','--export-filename='+str(folder/(self.name+'.png')),'--export-width='+str(self.w*2)],env=env,check=True,capture_output=True)
  self.drawio(folder/(self.name+'.drawio'))
  meta={'name':self.name,'title':self.title,'canvas':[self.w,self.h],'style':'Conventional UML; explicit grid positions; straight / orthogonal connectors','font':FONT,'nodes':self.nodes,'connectors':self.edges,'semantic_source':semantic}
  (folder/(self.name+'.json')).write_text(json.dumps(meta,indent=2,ensure_ascii=False))
  return {'file':self.name,'title':self.title,'type':'Editable draw.io, SVG and semantic JSON','connectors':len(self.edges)}
 def drawio(self,path):
  root=Element('mxfile',host='app.diagrams.net',type='device');diagram=SubElement(root,'diagram',name=self.title,id=self.name);model=SubElement(diagram,'mxGraphModel',dx=str(self.w),dy=str(self.h),grid='1',gridSize='10',guides='1',tooltips='1',connect='1',arrows='1',fold='1',page='0',pageWidth=str(self.w),pageHeight=str(self.h));r=SubElement(model,'root');SubElement(r,'mxCell',id='0');SubElement(r,'mxCell',id='1',parent='0')
  for n in self.cells:
   cell=SubElement(r,'mxCell',id=n['id'],value=n['value'],style=n['style'],vertex='1',parent='1');x,y,w,h=n['box'];SubElement(cell,'mxGeometry',{'x':str(x),'y':str(y),'width':str(w),'height':str(h),'as':'geometry'})
  for i,e in enumerate(self.edges):
   attr={'id':f'edge{i}','edge':'1','parent':'1','value':'','semanticLabel':e['semantic_label']}
   style=f'edgeStyle=none;rounded=0;html=1;strokeColor={INK};strokeWidth=1.65;endArrow={"none" if e["arrow"]=="none" else "open" if e["arrow"]=="open" else "block"};endFill={0 if e["arrow"]=="open" else 1};'
   if e['dashed']:style+='dashed=1;dashPattern=8 5;'
   for role,p in [('source',e['points'][0]),('target',e['points'][-1])]:
    id=e.get(role)
    if id in self.nodes:
     x,y,w,h=self.nodes[id]['box'];u=(p[0]-x)/(w or 1);v=(p[1]-y)/(h or 1)
     if -.01<=u<=1.01 and -.01<=v<=1.01:
      attr[role]=id;style+=f'{"exit" if role=="source" else "entry"}X={u};{"exit" if role=="source" else "entry"}Y={v};{"exit" if role=="source" else "entry"}Perimeter=0;'
   attr['style']=style;cell=SubElement(r,'mxCell',attr);g=SubElement(cell,'mxGeometry',{'relative':'1','as':'geometry'});SubElement(g,'mxPoint',{'x':str(e['points'][0][0]),'y':str(e['points'][0][1]),'as':'sourcePoint'});SubElement(g,'mxPoint',{'x':str(e['points'][-1][0]),'y':str(e['points'][-1][1]),'as':'targetPoint'});arr=SubElement(g,'Array',{'as':'points'})
   for x,y in e['points'][1:-1]:SubElement(arr,'mxPoint',x=str(x),y=str(y))
  Path(path).write_bytes(tostring(root,encoding='utf-8',xml_declaration=True))
