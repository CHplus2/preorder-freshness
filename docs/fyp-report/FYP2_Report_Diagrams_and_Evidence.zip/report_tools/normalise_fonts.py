"""Apply explicit Times New Roman and remove Word theme font overrides.
Images are preserved byte for byte. Used for final report generation only.
"""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
A='http://schemas.openxmlformats.org/drawingml/2006/main'
N={'w':W,'a':A};FONT='Times New Roman'
def tag(n):return '{'+W+'}'+n

def set_face(fonts):
 for key in list(fonts.attrib):
  if etree.QName(key).localname.lower().endswith('theme'):del fonts.attrib[key]
 for name in ['ascii','hAnsi','eastAsia','cs']:fonts.set(tag(name),FONT)

def normalise(path):
 path=Path(path);rows=[];changes=0
 with ZipFile(path) as z:
  for info in z.infolist():
   raw=z.read(info)
   if info.filename.startswith('word/') and info.filename.endswith('.xml'):
    tree=etree.fromstring(raw)
    for fonts in tree.xpath('.//w:rFonts',namespaces=N):set_face(fonts);changes+=1
    # Explicit defaults prevent unstyled field, footer and list text reverting.
    if info.filename=='word/styles.xml':
     for style in tree.xpath('./w:style',namespaces=N):
      props=style.find(tag('rPr'))
      if props is None:props=etree.SubElement(style,tag('rPr'))
      fonts=props.find(tag('rFonts'))
      if fonts is None:fonts=etree.Element(tag('rFonts'));props.insert(0,fonts)
      set_face(fonts)
    # Apply also to field results and hyperlinks omitted by python-docx .runs.
    for run in tree.xpath('.//w:r[w:t]',namespaces=N):
     props=run.find(tag('rPr'))
     if props is None:props=etree.Element(tag('rPr'));run.insert(0,props)
     fonts=props.find(tag('rFonts'))
     if fonts is None:fonts=etree.Element(tag('rFonts'));props.insert(0,fonts)
     set_face(fonts)
    for element in tree.xpath('.//w:lvlText',namespaces=N):
     if element.get(tag('val'))=='\uf0b7':element.set(tag('val'),'•')
    for element in tree.xpath('.//a:majorFont/a:latin | .//a:minorFont/a:latin',namespaces=N):element.set('typeface',FONT)
    raw=etree.tostring(tree,encoding='UTF-8',xml_declaration=True,standalone=True)
   rows.append((info,raw))
 tmp=path.with_suffix('.font-normalised.docx')
 with ZipFile(tmp,'w',ZIP_DEFLATED) as z:
  for info,raw in rows:z.writestr(info,raw)
 tmp.replace(path)
 return changes

if __name__=='__main__':
 import sys
 for name in sys.argv[1:]:print(Path(name).name,normalise(name),'font references normalised')
