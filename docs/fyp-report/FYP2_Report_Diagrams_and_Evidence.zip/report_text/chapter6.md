# CHAPTER 6 — CONCLUSION AND SUGGESTIONS

## 6.1 INTRODUCTION

This final chapter reviews the project against its unchanged objectives, discusses development challenges, advantages and limitations, and prioritises future improvements. Dapur Kita is a web-based system for one home-food business rather than a marketplace or a universal solution for every seller. Chapters 3 and 4 describe its implemented design, while Chapter 5 supplies repeatable software-verification evidence and an honest boundary for user evaluation.

The project integrates a branded storefront, flexible preordering, recipe-aware planning, dated ingredient inventory, analytics and recommendations. Supporting test payments, reminder emails, courier coordination and FreshCast expand the demonstration without replacing the original academic purpose. References and appendices follow this chapter; they are supporting matter rather than additional main chapters.

## 6.2 ACHIEVEMENT OF THE PROJECT OBJECTIVES

### 6.2.1 FLEXIBLE DATE-BASED PREORDERING AND SCHEDULING

The system implements future date/time selection, per-menu offered dates and weekdays, order cutoffs, advance notice, daily quantity limits and independent preparation/delivery/collection hours. Whole-basket feasibility checks consider one worker, equipment, closures and accepted commitments. Calculated and manual-reviewed plans, bounded searches for later times and guarded multi-day work support flexibility without automatically overriding handling limits.

Confirmed plans and unpaid requests are explicit states. Snapshots retain accepted recipes, preparation and fulfilment terms, while signed previews and transactional confirmation support changes. Grouped progress and shared cooking reduce repeated administration in compatible cases. These functions demonstrate the first objective’s implementation. The remaining evaluation is whether intended operators and customers can use them efficiently under representative workload; software tests alone cannot establish that outcome.

### 6.2.2 INGREDIENT SHELF LIFE AND STORAGE-DURATION MONITORING

The inventory module supports printed dates, manufacture-plus-life and receipt-plus-life evidence, optional reusable guidance, earlier opened/thawed limits, handling holds and remaining-window indicators. Received, expired, future and held stock are treated explicitly. FEFO and recorded consumption connect the monitoring feature to actual cooking and traceability rather than a random freshness label.

The second objective is implemented as record-based monitoring. Its contribution is a structured operational aid, not a sensor or food-safety certification. Unlabelled wet-market food still requires reliable guidance matching its actual storage and state. The owner must not equate a date or green indicator with an assurance that food is safe.

### 6.2.3 PERSONALISED SINGLE-VENDOR STOREFRONT

The owner can maintain kitchen identity, story, service/contact information, menus, categories, prices and photographs, including local image uploads. The public catalogue presents that kitchen’s products and does not introduce a competitor feed. Optional size groups, selling units and fixed-content descriptions represent different home-food offers clearly.

These features fulfil the implementation scope of the third objective. Whether they measurably strengthen a specific seller’s brand should be assessed through owner and customer feedback. The current project is a configurable single-kitchen installation, not a hosted multi-vendor management platform with tenant isolation.

### 6.2.4 SALES ANALYTICS AND DATA-DRIVEN DECISIONS

The owner can inspect defined sales/menu trends, current recipe estimates, actual contribution where evidence is complete, expenses, waste and exports. FreshCast compares future recipe need with dated stock and explains unused expiry stock and shortages. Distinct data sources and missing-cost labels prevent estimates from being silently presented as realised profit or physical waste.

The fourth objective is supported by implemented calculations and tested report behaviour. Data quality remains a condition: generated history, missing batch costs and absent delivery dates limit interpretation. Representative real records and task-based owner evaluation are needed before claiming better financial or purchasing outcomes.

### 6.2.5 MENU RECOMMENDATIONS, DECISION FATIGUE AND CONVERSION

The system implements two complementary recommendation surfaces: immediate explainable menu cards and an optional date/quantity/budget finder. The finder permits mixed or one-menu alternatives, checks the total order and whole-basket capacity, and retains honest empty/recovery states. Session-bound telemetry supports later engagement analysis.

The fifth objective’s recommendation system is implemented, but its intended reduction in decision fatigue and improvement in conversion are not yet empirically established by supplied participant data. The objective is deliberately retained unchanged. The planned counterbalanced task comparison and, where appropriate, a real conversion study should determine whether the mechanism produces those effects. A passing recommendation test or generated purchase cannot answer that behavioural question.

## 6.3 DEVELOPMENT CHALLENGES AND RESPONSES

### 6.3.1 DISTINGUISHING PLANNING FROM ACTUAL EVENTS

A major challenge was avoiding one status or date implying several different facts. A saved request is not accepted preparation; food readiness is not payment; dispatch is not delivery; projected expiry loss is not recorded waste. The response was to separate snapshots, financial events, inventory consumption and owner-confirmed progress, with contextual queues and recovery actions. This adds data concepts but makes the records more defensible.

### 6.3.2 FLEXIBILITY WITHOUT UNDOCUMENTED HANDLING ASSUMPTIONS

Some early combinations could not fit kitchen hours or required every menu to finish at the same dispatch instant. The scheduler was refined to allow a flexible same-day finish window, documented earlier work, independent batches and supported pause/resume tasks. However, making every task splittable or expanding an early-finish period without evidence would create a false capacity promise. The system therefore exposes constraints and reviewed alternatives rather than guaranteeing that any quantity fits any requested time.

### 6.3.3 HISTORICAL INTEGRITY AND CHANGING MENUS

Menus, ingredients, prices and delivery defaults change during development and business operation. The application now keeps accepted names/prices, ingredient quantities, preparation terms, address and fulfilment settings. Historical renamed menus are excluded from inappropriate local forecast mapping. Archive/deletion policies and explicit current-settings adoption protect relevant commitments. This supports traceability without inventing cooking costs for synthetic history.

### 6.3.4 EXTERNAL PAYMENTS, EMAIL AND RECOVERY

External systems can approve an operation while the browser loses its response. Checkout UUIDs, order-bound provider identities, transaction hashes, ledger events and retry rules preserve recoverable evidence. SMTP receipts reduce routine duplicate reminders, although inbox delivery and the acceptance/receipt crash window remain external limits. Sandbox and testnet environments permit demonstration while retaining clear disclosures. These challenges require more than displaying a success alert.

### 6.3.5 DATA QUALITY AND PREDICTIVE CLAIMS

The availability of a trained Genpact model did not make it a trained predictor for the kitchen’s different dishes. The system separates external IDs and simulated operations from database recipes and bookings. Local statistical baselines and coverage warnings remain useful when genuine history is sparse. The unsuccessful offline local candidate reinforced the need to compare models with baselines rather than assuming additional complexity creates accuracy.

### 6.3.6 OWNER WORKLOAD AND MOBILE USABILITY

Repeated status actions, long forms and technical diagnostic text can burden a sole operator. Progressive disclosure, focused daily queues, optional intermediate stages, grouped handover, compact cards, reliable timed notifications and retained drafts respond to that problem. Desktop and phone checks found and corrected concrete interface issues, but representative owner sessions are still needed to evaluate whether daily use is manageable.

## 6.4 ADVANTAGES OF THE IMPLEMENTED SYSTEM

The first advantage is integration around one kitchen’s accepted order. The same order connects the customer’s chosen food and handover with accepted recipes, time reservations, actual stock use, payment evidence and later reporting. That is more structured than relying on an unlinked conversation and a separate spreadsheet, while the owner can still use WhatsApp and an external courier where needed.

A second advantage is explicit evidence. Unknown costs remain unknown, a review request stays unconfirmed, scenario stock is not physically deducted, and forecasts carry their source. This supports explainability for both a project demonstration and future business use. It also gives a supervisor traceable examples of negative and retry cases rather than only screenshots of successful pages.

A third advantage is configurable local operation. Selling units, daily limits, specific dates, cutoffs, collection hours, fees and fixed contents can represent meals, bakes, small batches and occasional offers. Seasonal shipping enquiries are handled as conversations rather than forced into a local delivery promise. The system is therefore suitable for a useful range of home-food profiles without claiming universal coverage.

A fourth advantage is recovery and maintainability. The code is versioned, migrations and source/model backups are separate from private data, bounded APIs control work, and tests exercise actual concurrency boundaries. A lost browser response or failed settings save has an explicit recovery route. These are practical foundations, although continued maintenance and deployment checks remain necessary.

## 6.5 LIMITATIONS

| Area | Present limitation | Practical implication |
| --- | --- | --- |
| Scheduling | Conservative bounded greedy search; one worker and one unit per resource | Some feasible manual arrangements may not be discovered; larger kitchens need another resource model |
| Multi-day food work | Depends on documented waits, pauses and finish allowances | A larger span alone does not justify safe holding or interruption |
| Ingredients | Plans allocate advisory stock; procurement is not an integrated supplier purchasing system | Future bookings can need purchases; actual cooking can still be blocked by a shortage |
| Freshness | Owner-entered dates and conditions; no continuous physical measurement | Incorrect evidence or storage breaches can invalidate the record’s practical usefulness |
| Finance | Contribution is narrower than net profit; missing actual costs remain unknown | Generated history and current estimates cannot reconstruct historical accounting |
| Payments | PayPal Sandbox and Sepolia prototype; manual transfer needs external confirmation | No claim of production-money merchant readiness or audited escrow security |
| Courier | Manual booking/tracking and owner-confirmed events | No automatic GrabExpress ETA or verified delivery event |
| Email | Polling, consent, SMTP and provider queues; at most three attempts per call | Delays or missed inbox receipt remain possible; workload may require capacity review |
| Recommendations | Heuristic ranking and bounded candidate search | Not exhaustive, not an allergy assessment and not proven to improve real conversion |
| Forecasts | Sparse/generated local history; external Genpact scope | Demonstration metrics do not establish local customer accuracy or realised waste reduction |
| Validation | Automated/local evidence and a prepared user protocol | Real owner/customer usability and business outcomes remain unmeasured |

The application also depends on connectivity, correct deployment configuration and private backup discipline. Local tests cannot certify live database access policies, email scheduler cadence or the current production alias. Automated accessibility checks cover selected states rather than every assistive-technology journey. These limits should be retained in a final report instead of being removed to make the system appear complete.

## 6.6 PRIORITISED FUTURE DEVELOPMENT

### 6.6.1 VALIDATION WITH INTENDED USERS

The highest priority is to execute the objective-linked owner/customer protocol in Chapter 5, retain anonymised raw observations and correct/retest discovered problems. Measure selection time, comprehension and task success before claiming reduced effort or conversion improvement. A pilot with representative home-food operators should examine whether their actual batch, cutoff, pickup and handover practices match the configuration model.

### 6.6.2 REPRESENTATIVE DATA AND FINANCIAL COMPLETENESS

Collect consistently dated real completed sales and stable menu identities with consent and suitable privacy controls. Record actual consumption and batch costs where contribution is required. For forecasting, compare baselines and any learned candidate with chronological validation and untouched tests across meaningful periods. Do not replace real demand with synthetic records to improve a metric. More complete supplier/procurement and financial reconciliation workflows should precede claims of full business accounting.

### 6.6.3 OPERATIONAL RELIABILITY AND MONITORING

Review reminder throughput against real volume, monitor queue age and failed sends, and verify the chosen scheduler rather than enabling duplicate schedules. Provider delivery/bounce information, bounded job recovery and operational alerting can improve observability. Retain consent and current-recipient checks. Stronger operational monitoring should also cover failed payments, stale plans, backups and release migration checks.

### 6.6.4 MORE GENERAL CAPACITY MODELLING

A future scheduler could support multiple workers, equipment quantities, delivery-route reservations and more systematic search, while preserving accepted commitments and stock evidence. Shared cooking could expand beyond the current strict compatible single-menu case after its physical and accounting implications are defined. Any optimisation should be evaluated against a clear baseline and real recipes; an algorithmic fit must not override food-handling limits.

### 6.6.5 OPTIONAL INTEGRATIONS AND SECURITY REVIEW

A courier adapter remains optional and is not required for the present FYP scope. If later justified by business need and approved provider access, it should use authenticated, deduplicated provider events and preserve manual exception handling. Automated WhatsApp messaging similarly requires official platform arrangements and consent; ordinary draft links should remain usable without it. Live payments or broader escrow require provider approval, secure operational setup and independent review before real funds are introduced.

## 6.7 MAINTENANCE AND HANDOVER

Maintain separate copies of source code, the original model archive and private PostgreSQL data, including uploaded photographs. Verify recovery in an isolated environment and retain archive hashes. Apply schema changes through a documented maintenance process before releasing code requiring them. Do not solve a failed deployment by disabling its migration guard or placing database credentials in public source.

For a demonstration, start with internally consistent menu notice, capacity, task, date and stock settings. Clearly identify generated history and test payments. After changing orders, stock or settings, refresh relevant planning views. Confirm actual readiness and handover rather than allowing the passage of time to claim physical completion. A short operating guide and source map are provided in the appendices for repeatable handover.

## 6.8 CONCLUSION

Dapur Kita implements the five intended feature areas in one single-vendor web application: flexible preordering, record-based ingredient freshness, personalised branding, analytics and menu recommendations. The current verification supports its stated calculations, access boundaries, retry behaviour and selected interface flows. It also demonstrates how accepted order evidence can connect planning to actual stock consumption and later reporting.

The project should be presented as an implemented and tested academic system with explicit operating limits. It has not yet demonstrated real-world conversion uplift, reduced waste, guaranteed punctual delivery or physical food safety. Completing the proposed user evaluation and collecting representative operational evidence are the next steps for judging those effects. Within those boundaries, the work provides a coherent foundation for a home-food operator and a traceable basis for further study.
