# CHAPTER 5 — TESTING AND RESULTS

## 5.1 INTRODUCTION

This chapter evaluates the implemented system against the original five objectives. It separates functional verification, database concurrency checks, interface inspection, external-model evaluation and validation with intended users. The university briefing highlights testing that is verifiable, handles exceptions and security concerns, and relates findings to the objectives. Accordingly, a passing screen or build is not used as evidence of customer satisfaction, real food safety, commercial conversion or on-time courier delivery.

The latest verification was executed for source revision ab1a976 on 29 October 2026. Tests used disposable local databases, in-memory email or mocked provider responses. Current screenshots were captured with isolated test accounts and data. No production customer order, stock quantity, payment or email subscription was changed for this report. Earlier dated browser and external-model checks are identified as retained evidence rather than newly invented field observations.

## 5.2 TESTING APPROACH AND ENVIRONMENT

The approach combines white-box unit tests for calculations, black-box API behaviour, integration/retry tests, PostgreSQL concurrency tests and browser-based interface checks. Positive cases are paired with rejected inputs, stale state, duplicate requests and interrupted responses. The same assertion can serve more than one objective, but it is counted once in its suite. Model metrics are reported separately from software test counts.

| Environment or evidence | Configuration / scope | What it establishes |
| --- | --- | --- |
| Application baseline | Git ab1a976; React/Django code and current migrations | Reproducible source identity, not production deployment status |
| Full backend regression | In-memory SQLite; dotenv disabled; in-memory mail; restored original model paths | Application calculations, permissions and response contracts |
| Concurrency/SQL checks | Temporary PostgreSQL 16; loopback-only TLS connection; disposable database | Actual row locks, races, transactional effects and schema-qualified correction SQL |
| Frontend verification | Node utility/rendering suites, ESLint and Vite production build | Tested response/state logic, component output and compilability |
| Browser evidence | Chromium; actual local bundle; selected 1440/768/390/320-pixel states | Tested interaction/recovery, selected automated accessibility and overflow checks |
| External-model evidence | Original checksum-verified CatBoost artifact and its historical holdout | Reproduced external-data prediction error, not local business accuracy |
| User evaluation | Protocol prepared; no supplied participant observations | An executable future validation method, not completed UAT |

The regression manifest records each command, exit code and log SHA-256. The full backend run discovered 829 tests. It executed 806 successfully in SQLite and skipped 23 requiring PostgreSQL. Those same 23 were then executed separately against PostgreSQL and all passed. Thus all 829 discovered application tests were exercised across the two database environments; this does not mean that all 829 were repeated on PostgreSQL. The restored-model tests ran rather than being skipped for missing artifacts.

The first temporary PostgreSQL setup lacked the TLS support required by the application connection settings, so it failed before tests executed. The fixture was rebuilt with local TLS and the full 23-check selection then passed. The application’s production TLS requirement was not weakened to obtain a passing result. This setup correction is distinguished from a product defect or a production database failure.

## 5.3 DECISION TABLES

### 5.3.1 CHECKOUT AND REQUEST CONFIRMATION

| Rule | Sale/date rules valid | Automatic preparation fits | Customer requests review | Expected outcome |
| --- | --- | --- | --- | --- |
| C1 | Yes | Yes | No | Recheck and save confirmed task plan with explicit available payment choice |
| C2 | Yes | No, permitted planning exception | Yes | Save unpaid deferred request; reserve no tasks |
| C3 | No: past date, closed cutoff or disallowed day | Any | Any | Reject; do not create a valid booking by calling it a request |
| C4 | Yes at quote, changed before placement | No longer matches | Any | Recompute or reject stale quote; do not trust old browser values |
| C5 | Yes | Yes | No; repeated same checkout UUID | Return existing valid result without another order/debit |
| C6 | Yes | Yes | Delivery with cash selected | Reject cash; cash is restricted to collection |

### 5.3.2 BATCH ELIGIBILITY AND DEADLINES

| Rule | Received by allocation date | Effective date not passed | Held | Evidence | Expected allocation result |
| --- | --- | --- | --- | --- | --- |
| I1 | Yes | Yes | No | Valid required input | Eligible positive stock; use FEFO ordering |
| I2 | No | Any | No | Any | Exclude future receipt |
| I3 | Yes | No | No | Any | Exclude expired batch |
| I4 | Yes | Yes | Yes | Any | Exclude held batch independently of date |
| I5 | Yes | Yes | No | Calculation mode lacks source/duration | Reject incomplete save; do not invent a life |
| I6 | Yes | Several limits | No | Earlier opened/thawed/printed limit | Earliest applicable deadline controls |

A displayed remaining-window percentage is not an additional safety decision rule. In particular, expiry-day stock can have zero remaining-window percentage while the calendar-day deadline has not yet passed. Uncertain handling remains a hold regardless of the percentage.

### 5.3.3 ACTUAL FOOD READINESS AND GROUPED PROGRESS

| Rule | Valid accepted plan / transition | Version current | Enough eligible stock | Already deducted | Expected outcome |
| --- | --- | --- | --- | --- | --- |
| F1 | Yes | Yes | Yes | No | Consume accepted ingredients once; log batches; mark ready |
| F2 | Yes | Yes | Any | Yes | Repeated readiness does not deduct stock again |
| F3 | No | Any | Any | No | Reject; confirm preparation before actual readiness |
| F4 | Yes | No | Any | Any | Reject stale selection; retain current state |
| F5 | Yes | Yes | No | No | Roll back all selected orders and deductions |
| F6 | Collection order | Yes | Not relevant to dispatch | Any | Reject out-for-delivery; confirm collection after actual handover |

### 5.3.4 PAYMENT, REMINDER AND BUDGET EVIDENCE

| Condition | Expected behaviour |
| --- | --- |
| PayPal browser says approved but verified amount/currency does not match | No completed ledger receipt or paid status |
| Sepolia hash is submitted but confirmations are insufficient | Retain recoverable pending evidence; remain unpaid |
| Repeated valid provider receipt or payment-choice request | One durable result; no duplicate charge/receipt caused by the application |
| Customer has only a phone number | Contact route remains available; no SMTP reminder to a phone number |
| Customer consent absent, email changed or plan unconfirmed | Exclude advance-reminder event |
| Successful reminder receipt already exists | Suppress routine repeat for that event; do not send every polling interval |
| Budget absent | No price restriction; comparison control inactive |
| Complete candidate total equals budget | Within; Above is strictly greater |
| Mixed basket target three with one current item | Add only two items to reach three total, subject to constraints |
| One-menu alternative replaces an existing basket | Require explicit replacement confirmation and current basket fingerprint |

## 5.4 FUNCTIONAL AND SECURITY TEST CASES

The following cases summarise executed automated tests. Each source name is a locator in backend/myapp or the named frontend utility, not a signature from an independent human tester. Logs include the individual test methods and outcomes. Test fixtures are intentionally synthetic and cannot substantiate user adoption or measured sales effects.

@functionaltests

## 5.5 REGRESSION RESULTS

| Verification group | Observed result | Interpretation / limit |
| --- | --- | --- |
| Full Django application discovery | 829 discovered; 806 passed in SQLite; 23 skipped there | The skip reasons require PostgreSQL features |
| Deferred PostgreSQL checks | 23 passed, zero skips, temporary PostgreSQL 16 | The skipped application checks were actually exercised separately |
| Release, archive, backup and entrypoint checks | 34 passed | Packaging/recovery controls and SPA entrypoint; not live Vercel health |
| Frontend core, UX, checkout and Planner suites | All commands passed | Tested state, calculations and rendering contracts |
| Recommendation, predictive and shopping suites | All commands passed | Source/budget/session boundaries and response handling |
| PayPal, escrow and image suites | All commands passed | Local verification/recovery and image-processing behaviour |
| ESLint | Passed | Static checks; does not prove absence of security defects |
| Vite production build | Passed | Bundle compiled; does not measure live loading time |
| Production providers / real customers | Not exercised in this run | No inferred SMTP inbox, live capture, courier or UAT result |

The current pass results supersede the 29 September snapshot in the earlier Chapters 4–6. That historical draft reported 87 backend tests, frontend lint errors and an unresolved escrow test. It would be inaccurate to carry those outcomes forward as the present release status. Equally, passing the larger suite is not proof that every possible defect has been removed. Exact commands, identities and logs accompany this document’s evidence package, and Appendix F maps the principal source files.

## 5.6 INTERFACE, RECOVERY AND PERFORMANCE FINDINGS

### 5.6.1 RESPONSIVE AND ACCESSIBILITY CHECKS

Retained browser checks for the latest five-page review exercised menu, basket, checkout, Settings and My orders at desktop, tablet and phone widths. Their assertions checked selected WCAG A/AA-related Axe rules, document overflow, error states and actual production-bundle interactions. The Settings review covered delayed saves and failed-save draft retention; the history review covered filters, repeated pages, a failed append, a failed refresh and stale delayed responses. The latest notification review included a five-second delayed basket refresh, repeated quantity notices, removal and a confirmed write followed by a failed read.

In those documented states, the automated checks reported no violations of the selected rules or horizontal document overflow. These are constrained results: keyboard-only usability, screen-reader comprehension and complete WCAG conformance are not established by Axe alone. The screenshots newly captured for this report illustrate the current implementation and were visually inspected; capturing an image is not an additional human participant test.

### 5.6.2 DEFECTS AND RETESTED CORRECTIONS

| Concrete trigger | Earlier behaviour | Current correction and verification |
| --- | --- | --- |
| Slow basket GET after a successful Add | Toast interval could run while the action still appeared busy | Success starts after refresh; browser delay test passes |
| Quantity increase/removal | No success popup for those paths | Distinct timed notices; repeated actions tested |
| Successful basket write but failed read | Ambiguous recovery could encourage another Add | Saved-change information; one persisted addition verified |
| Ten-box banana-cake preview with eight-box daily cap | Default sample immediately warned without explaining the numeric mismatch | Default respects cap; explicit over-limit sample and preview-only correction tested |
| Edit Settings while save is pending | Later response could overwrite newer draft edits | Related controls disabled during save; failure retains draft |
| Long customer history | Full history fetched despite ten initially displayed cards | Ten-row API paging, private counts and stable cursor |
| One-menu finder with an existing basket | Existing item could dominate alternatives | Independent alternatives and explicit replacement confirmation tested |
| Delivery checkout with hidden cash selection | Could imply unsuitable courier cash collection | Server rejects delivery cash; collection cash remains available |

These corrections address visibility, consistency, error prevention and recovery rather than merely changing colours. The observed behaviour supports Nielsen’s principles applied in Chapter 4. It does not quantify reduced owner workload or customer abandonment, because timed user sessions and field data were not supplied.

### 5.6.3 BOUNDED WORK AND QUERY EVIDENCE

The order-history regression increases a customer’s fixture history to 1,000 records while keeping a page at ten records and the data-query count at no more than three in the controlled API fixture. It verifies owner-scoped counts, stable older-ID pages when new orders arrive, and rejection of malformed or repeated parameters. The query count excludes the cost of normal production authentication middleware and does not establish a production latency target.

Other bounded interfaces include menu pagination, at most 30 whole-basket capacity checks in the finder, at most 20 grouped progress updates and a three-email attempt budget per worker call. Uploaded media is bounded and re-encoded, and optional payment/forecast components are separated from ordinary catalogue browsing. The current build also retains a main-chunk size advisory above 500 kB after minification. Build success does not remove that optimisation opportunity. These limits control work but are not a load test. No live Core Web Vitals, peak concurrent-user capacity, database capacity forecast or guaranteed email throughput was measured for this report.

### 5.6.4 SECURITY AND CONCURRENCY FINDINGS

Access tests distinguish public menu data, a customer’s own basket/orders and staff business records. CSRF is required for state-changing session requests. Forged price, paid flags, foreign order IDs, stale versions and invalid provider evidence do not gain authority. Photo uploads validate decoded content rather than trusting an extension or MIME string. Financial CSV text is protected against spreadsheet-formula interpretation. Test provider endpoints reject evidence that does not bind to the accepted order.

The 23 PostgreSQL cases exercise simultaneous final-capacity checkout, repeated checkout IDs, recipe/plan confirmations, wallet concurrency, grouped basket replacement, account-email identity, reminder worker overlap, deletion locks and stock edits/consumption. These tests establish the selected race outcomes under actual row locking. They are not an external penetration test, a review of all deployed Supabase RLS policies or an audit of the public Sepolia contract deployment. Runtime secrets, scheduler activation, SMTP configuration and live provider identities require operational verification.

## 5.7 FORECAST EVALUATION AND DATA LIMITS

### 5.7.1 EXTERNAL GENPACT MODEL RECOVERY

The retained 29 October model-recovery evidence restored the original runtime archive, verified SHA-256 697f8e10ee6b2c1b794ee38ec81067477870315fb7c51a1280684e7f0601361a and reloaded its saved model. Independent predictions on the original 32,821-row holdout reproduced the stored rounded metrics. This was artifact recovery and re-evaluation, not new training or an independent new test set.

| Measure | Reproduced value | Evaluation context |
| --- | --- | --- |
| Historical source size | 456,548 rows, 77 centres | External centre/meal dataset |
| Holdout | Weeks 136–145; 32,821 rows | Earlier weeks used for training |
| CatBoost WAPE | 28.23494% | Rolling one-step-ahead predictions |
| Previous-observation baseline WAPE | 34.80762% | Same holdout and demand target |
| Absolute WAPE difference | Approximately 6.57 percentage points lower | Error comparison, not sales uplift |
| API checks in the retained recovery run | 17 passed, zero skips | Actual restored artifact used; no production DB |

@figure model-wape | Figure 5.1: Reproduced Genpact rolling one-step WAPE on the original holdout; lower is better.

WAPE is 100 × sum of absolute prediction errors divided by sum of absolute actual demand. A 28.23% WAPE is not 71.77% customer accuracy or a guarantee about each meal. The holdout uses actual earlier observations as they become available; multi-week recursive performance and promotion causality are different questions. The external model’s lower error supports this benchmark comparison, while its transfer to a small kitchen with different named menus is not established.

### 5.7.2 KITCHEN FORECASTS AND SYNTHETIC HISTORY

The kitchen path can translate eligible local demand into recipe needs without a Genpact model. Its menu-level baseline selection and held-out calculations are deterministic and tested for chronological separation. However, much of the showcase history is generated, and zero recorded sales on absent days may reflect missing recording rather than true no-demand days. Renamed-menu exclusions, date fallbacks, paid/delivered eligibility and order-coverage warnings are necessary for interpreting the output.

Changes to preparation dates, order status, recipe identity or stock records can change included bookings, costs and future allocations. They do not by themselves create more representative historical demand. The normal baseline calculation reads current eligible history; the saved Genpact model does not need retraining merely because a planner task is corrected. Fitting a more complex local model is justified only after collecting consistent representative history and comparing it chronologically with simple baselines.

A prior offline aggregate local-booking experiment did not outperform its four-week baseline and is not the live predictor. This is a useful negative finding: connecting a database and adding machine learning does not guarantee better prediction. No new kitchen accuracy percentage, waste reduction, realised savings or marketing uplift is claimed from generated orders or forecasts in this report.

## 5.8 VALIDATION AGAINST THE OBJECTIVES

| Original objective | Implemented and verified evidence | What remains to validate |
| --- | --- | --- |
| 1. Flexible date-based preordering and scheduling | Whole-basket quotes, menu dates/cutoffs, independent hours, accepted plans, guarded multiday work and replanning | Task success and acceptable booking effort for actual owners/customers |
| 2. Freshness by shelf life and storage duration | Three evidence modes, reusable guidance, effective deadlines, holds, FEFO and traceable consumption | Correct application of guidance in practice; no physical-safety claim |
| 3. Personalised single-vendor storefront | Kitchen identity/story, menu/category/photo management and a competitor-free storefront | Owner branding comprehension and usefulness in a real deployment |
| 4. Sales analytics for decisions | Defined sales/cost cohorts, contribution unknowns, expenses/waste, exports and source-labelled forecasts | Operator interpretation and improved decisions using representative data |
| 5. Recommendations reducing fatigue and improving conversion | Explainable immediate cards, optional mixed/same-menu finder, budget/capacity checks and telemetry | Decision-time/fatigue comparison and genuine conversion outcomes |

The matrix supports implemented feature coverage and verified behaviour. It does not rewrite Objective 5 to avoid its outcome claim. That outcome remains an evaluation question. Observational recommendation events can describe engagement, but repeat visits, menu price, availability and exposure differences can confound causal conversion comparisons. A simulated completed checkout is task completion, not a commercial sale.

## 5.9 USER ACCEPTANCE AND FIELD-EVALUATION PROTOCOL

### 5.9.1 STATUS, PARTICIPANTS AND ETHICS

No genuine respondent dataset, completed evaluation form, signed independent test sheet or field timing observations were supplied for this report. Accordingly, this section specifies the prepared evaluation rather than claiming it happened. The senior report’s participants, percentages, signatures and charts are not reused. The supervisor should agree recruitment size, consent, ethical requirements and the final rubric before any session. The supplied briefing does not independently prescribe a universal sample size.

Recruit participants representing both home-food operators and customers. Use participant codes instead of names in analysis and test orders instead of real financial transfers. Record role, device, viewport, source revision and relevant experience. Explain that date-based freshness is a planning record and test payments move no real funds. Permit withdrawal and minimise unnecessary personal data. Keep consent and any private contact details separate from anonymised observations.

### 5.9.2 TASKS LINKED TO OBJECTIVES

| Task | Participant role | Action and success criterion | Objective |
| --- | --- | --- | --- |
| U1 | Customer | Find an available menu, select a future handover and save a valid test preorder | 1 |
| U2 | Customer | Recover from an unavailable date without guessing several rejected times | 1 |
| U3 | Owner | Record unlabelled chilled stock using a matching documented reference; identify its deadline and hold | 2 |
| U4 | Owner | Explain why a held/expired batch cannot cover an accepted order | 2 |
| U5 | Owner | Update kitchen story/contact and a menu image, then locate the public result | 3 |
| U6 | Customer | Identify the single kitchen and its collection/delivery/contact conditions | 3 |
| U7 | Owner | Explain the difference between unknown contribution, a cost estimate and actual food contribution | 4 |
| U8 | Owner | Interpret a shortage alongside an expiring surplus and choose a justified review action | 4 |
| U9 | Customer | Choose a valid three-item basket within a stated whole-order budget using ordinary browsing | 5 |
| U10 | Customer | Complete an equivalent choice using recommendations and describe the reasons/total | 5 |
| U11 | Owner | Confirm several eligible ready orders and identify a deliberately ineligible member | 1, 4 |

Record independent/assisted/failed completion, elapsed time, errors, requests for help and whether the participant can explain the outcome. Do not count a task completed by the facilitator as independent success. Interview notes should distinguish interface confusion from deliberately inconsistent fixture settings.

### 5.9.3 RECOMMENDATION COMPARISON AND SURVEY

Use equivalent menu-choice tasks with the same date, quantity and budget constraints. Counterbalance whether each participant starts with browsing or recommendations and rotate the food sets to reduce learning effects. Measure time to a valid selection and perceived decision difficulty using the same scale. Report medians and dispersion, completion counts with denominators and common qualitative problems. A small convenience sample can suggest improvements but does not establish population-wide efficacy.

The short survey in Appendix E maps each question to the objectives. A five-point agreement scale can be used consistently, with a separate not-applicable option. Ask about successful tasks and observed difficulty rather than asking whether the participant agrees the project is successful. Retain anonymised raw data and calculation rules before generating charts. If real conversion is studied later, predefine exposure, purchase window, consent/privacy handling and comparison conditions; do not label unrelated page visits as attributed purchases.

### 5.9.4 ACCEPTANCE, DEFECT HANDLING AND REPORTING

Agree acceptance criteria before collection. At minimum, no unauthorised cross-account disclosure, duplicate charge, stock overdraw or false delivered state is acceptable. Owner/customer tasks must have defined valid outcomes and understandable recovery. For every observed problem, record severity, reproduction steps, source revision, correction and retest result. Report assisted and failed tasks as well as successes. An independent reviewer can sign an actual execution record after testing; this report does not insert a fabricated sign-off.

The briefing’s consultation-log, originality/similarity-report and submission instructions require the student’s genuine documents. A completed software test log does not replace supervisor meetings or an institutional similarity report. These items are recorded as author completion requirements outside the main technical evidence.

## 5.10 DISCUSSION IN RELATION TO THE LITERATURE

Chapter 2 identifies the operational gap between informal ordering and more complex industrial food-monitoring systems. The implementation responds with accepted digital orders, explicit kitchen constraints and low-cost date evidence rather than requiring sensors or industrial routing infrastructure. This design is consistent with the relevance of food quality and service expectations discussed by Tan and Kim (2021) and the home-food safety perspective of Pallianysamy et al. (2025), while it cannot infer microbiological safety from those studies or from its own dates.

The distinction from advanced supply-chain work is practical scope. The application records and reasons about owner-entered evidence; it does not implement the physical monitoring examined by Tsang et al. (2019) or certify that a refrigerator maintained a temperature. It also separates operational planning from stochastic demand modelling and does not claim to reproduce the inventory-routing results discussed by Violi et al. (2024).

The menu finder addresses choice effort through a small explainable set, total-order prices and explicit recovery. That is a design rationale and a testable hypothesis, not a new experimentally demonstrated contribution to decision-fatigue literature. The external model benchmark supports one demand-error comparison only. The project’s contribution is the implemented integration of these lightweight workflows and traceable constraints for a single kitchen; practical business benefits remain hypotheses for the planned validation.

## 5.11 CONCLUSION

The current source passed its application, concurrency, release and frontend checks within the stated local environments. The strongest evidence concerns authoritative business rules, transaction/retry safety, dated stock, clear state separation and bounded interfaces. Model-recovery evidence is reproducible but external to the kitchen’s real demand. User acceptance, decision-fatigue reduction, conversion improvement and long-term food/operational outcomes require the genuine observations specified above. Chapter 6 draws conclusions within these limits.
