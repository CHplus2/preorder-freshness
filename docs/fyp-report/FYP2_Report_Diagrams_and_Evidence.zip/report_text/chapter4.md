# CHAPTER 4 — INTERFACE AND SYSTEM IMPLEMENTATION

## 4.1 INTRODUCTION

This chapter explains the implemented Dapur Kita website from customer and kitchen-owner perspectives. It also describes the architecture, calculations and integration boundaries behind the screens. The evidence baseline is Git revision ab1a976, reviewed on 29 October 2026. All screenshots in this chapter were captured from that application using isolated local test records; they are not photographs of a production business or evidence of real sales. Personal contact, payment-provider and production database credentials were not used for the captures.

The implementation extends the proposal without replacing its five objectives. Customers can browse first, receive optional recommendations, maintain a basket and choose a workable handover arrangement at checkout. Owners manage menus, preparation, stock, financial records and fulfilment from the same single-kitchen workspace. Additional functions—FreshCast, email reminders, assisted ordering and test payment integrations—support these core workflows rather than establishing new objectives.

## 4.2 APPLICATION ARCHITECTURE

@figure architecture | Figure 4.1: Implemented presentation, API, service and persistence layers.

The React frontend provides routed customer and owner pages, shared Context providers and reusable components. Vite produces the static application bundle. Django and Django REST Framework expose JSON endpoints and enforce authentication, CSRF, permissions, business validation and database transactions. PostgreSQL hosted by Supabase stores the application’s relational records. Vercel hosts the deployed application; it is not the persistent database. The configured database schema is django_app in the owner’s Supabase installation. The source review does not independently certify that installation’s current access policies.

This architecture uses Django models and views, but the interactive interface is React rather than a collection of Django-rendered business templates. PostgreSQL is accessed through Django’s ORM; the customer browser is not given the database connection string. An external scheduler invokes a narrow authenticated email worker. PayPal, Sepolia JSON-RPC and optional AI classification are separate configured services. The Genpact model/data bundle is provisioned as a versioned read-only runtime asset; ordinary kitchen operations do not need to train or load it.

| Layer | Main implementation | Responsibility |
| --- | --- | --- |
| Presentation | frontend/src/App.jsx; pages, components and Context providers | Navigation, forms, responsive views, loading/recovery and display state |
| API | backend/myapp/urls.py; views; serializers.py | Access checks, strict inputs, bounded responses and authoritative operations |
| Domain services | services/scheduling.py, work_sessions.py, order_progress.py and recommendation.py | Preparation constraints, actual progress and explainable ranking |
| Stock and finance | InventoryItem, OrderIngredient, IngredientConsumption, PaymentEvent and report services | Accepted requirements, dated stock, audit evidence and financial calculations |
| Decision support | kitchen_decisions.py, kitchen_forecast.py and predictive_ai | Distinct local and external forecast paths; read-only scenarios |
| Integrations and operations | PayPal/escrow services, reminders.py, GitHub worker workflow and build.py | Independent provider verification, bounded email execution and release checks |

The application uses decimal values for money and measured quantities at the transactional boundary. Frontend labels format values for the reader but do not determine server prices or inventory deductions. Public menu data is separated from private customer and staff records. Optional interfaces are loaded as needed; a missing provider configuration does not silently turn a test mechanism into a real payment service.

## 4.3 CUSTOMER INTERFACES

### 4.3.1 STOREFRONT, MENU AND PRODUCT DETAILS

The public storefront presents one kitchen’s name, story, contact route, food categories and menu photographs. It does not surround a seller’s products with competitors’ listings. Customers can search the menu and switch categories before using assistance. Product details show the selling unit, price, notice requirements, permitted dates or weekdays, daily capacity, sizes/fixed contents where configured and a route for allergen questions. A box or pack is one selling unit; the number of pieces inside it is not automatically the number of diners.

@figure screen-menu | Figure 4.2: Current customer menu with search, categories and compact food cards (local test records).

@figure screen-product | Figure 4.3: Product detail showing price, selling unit and preorder information (local test record).

The initial Add action changes into a minus/quantity/plus control once that menu is in the basket. The accompanying in basket caption makes the number’s meaning explicit. Increasing, reducing or removing a line updates the same basket rather than producing a new order. A fixed basket summary links to the next stage without obscuring the food grid on tested phone widths.

Archived products are retained for relevant order history, while new ordering uses active selling status. Paused and archived menus are not silently treated as available recommendations. Menu categories are owner-managed. A seasonal product can use a shipping-enquiry route: it opens a contextual conversation rather than accepting a local-delivery payment or promising a parcel arrival date.

### 4.3.2 ACCOUNTS, ADDRESSES AND CONTACT PREFERENCES

The current customer experience supports email-based account creation and email-or-username sign-in, retaining legacy username accounts. Password validation, recovery and attempt limits are enforced by the backend. An email-change workflow requires current-account proof and confirmation; an order’s reminder consent is not silently transferred to a different address. Saved addresses belong to the signed-in customer. The order stores the accepted address, so later address edits do not rewrite that delivery record.

Phone and preferred-contact details support a specific order’s handover. Optional instructions can be disclosed progressively rather than turning every contact preference into a required checkout task. An email address is required for SMTP reminders; a phone number alone cannot receive email. Opening a WhatsApp draft is a deliberate external contact action, not an automated WhatsApp Business notification. Customer account access does not grant the owner’s APIs.

### 4.3.3 TWO COMPLEMENTARY RECOMMENDATION SURFACES

Recommended for you provides immediate discovery without requiring a form. It ranks eligible active menus using paid, non-cancelled history and recent popularity. Customers without useful personal evidence receive an honest menu/popularity basis rather than invented preferences. The current routed ranking awards 25 points for a preferred category, up to 20 for earlier purchased quantities and up to 15 for recent popularity. Category history uses 180 days, menu history 365 days and global popularity 30 days. These are explainable heuristics; no training dataset or personalised neural model is implied.

The optional Menu suggestions for your date finder asks for a date, total item count, mixed/same-menu preference, optional whole-order budget and category preference. A date is required; leaving the budget blank means no price limit. Budget preference is disabled until a budget exists. The date is within the next 90 days and the item count is 1–100. Suggestions are alternative baskets. A target of three means three total items in a selected option, not three of every displayed dish.

Allow a mix keeps existing basket items and distributes only the remaining target quantity. One menu only searches independent repeated-menu alternatives; replacing an existing basket requires explicit confirmation. This avoids recommending only the already-present menu and prevents an unexpected destructive replacement. Up to three options are returned after pricing and shared capacity checks. The search is bounded to a seeded pool of up to 12 menus and at most 30 complete-basket capacity checks. It is useful decision support, not exhaustive combinatorial optimisation.

@figure screen-finder | Figure 4.4: Whole-order date finder with three total items and an optional RM100 budget (actual local search).

The budget comparison uses the complete candidate order total: food subtotal minus the current applicable bulk discount plus the current delivery fee. Existing basket items are included in mixed mode. Within includes equality; Above means strictly greater than the entered budget. Comparison occurs before the three-result limit. If all feasible candidates cost less than RM100, Above RM100 correctly has no results; it does not mean every menu omitted from the top three should appear. A missing category is distinguished from a scheduling failure.

For example, three RM12 boxes have a food line total of RM36, not RM36 each. If the configured delivery fee is RM5 and no discount applies, that candidate’s whole-order total is RM41. A mixed example of one RM12 box, one RM10 pack and one RM18 box has food subtotal RM40 and total RM45 under the same fee. Both fit RM100. These are arithmetic illustrations, not recorded orders or a price guarantee; checkout rechecks current accepted terms.

Adding a dated suggestion applies the basket and preserves the chosen day. It does not reserve or force an hourly handover slot. The customer chooses or reviews the final time at checkout, avoiding repeated time-selection controls across discovery, basket and checkout. Recommendation events record rendered exposure, selection and additions where applicable; telemetry failure must not prevent shopping. Objective 5’s intended decision-fatigue and conversion effects still require actual evaluation, described in Chapter 5.

### 4.3.4 BASKET AND FULFILMENT CHOICE

The basket groups food lines, quantities, the current summary and Receive your preorder. Delivery and self-collection appear only when the owner has enabled and completed their configuration. A collection address alone does not prove that collection is offered. Collection requires enabled service, a public location and valid collection hours. Delivery uses saved address details and configured area choices. A descriptive service-area sentence is separate from the short list of selectable area names.

@figure screen-basket | Figure 4.5: Basket quantities, fulfilment choice and authoritative summary (local test records).

Proceeding to checkout is appropriate because the basket is primarily a review step; required address, time and payment validation belongs to the checkout that creates the order. A basket failure hides the onward action until its contents can be read. An optional availability preview can help customers earlier, but it is not a second mandatory checkout form. Delivery and collection choices persist into the final quote and are revalidated there.

The owner’s delivery fee and optional free-delivery threshold are editable settings. They are not a live GrabExpress fare or a prediction learned from delivery history. The customer accepts the displayed fee at placement, and the order retains it. A higher later courier charge is a business arrangement to resolve explicitly; the system does not automatically charge the customer twice. Collection has no delivery fee or travel buffer. The current customer wording groups legacy express and standard delivery as Delivery while retaining accepted historical terms.

### 4.3.5 CHECKOUT, FEASIBLE TIMES AND REVIEW REQUESTS

Checkout presents delivery/collection, address where required, a time or supported arrival window, optional contact/handover preferences, reminder consent, payment options and the order summary. Availability depends on the entire basket. The server checks menu restrictions, order cutoffs, notice before preparation, kitchen resources, existing bookings, closures, daily selling-unit limits and handover hours. A quotation is advisory until placement rechecks under locks.

@figure screen-checkout | Figure 4.6: Checkout separates fulfilment, address, time and payment (local test record; no payment submitted).

The next-available-day search reduces trial and error when a preferred day has no automatic time. A rejection explains the relevant rule rather than using one generic unavailable message. Current ingredient stock and kitchen time are separate: the owner may procure ingredients for a future booking, but the owner must resolve a shortage before actual cooking can be recorded.

A customer may explicitly submit an eligible request needing kitchen review. The saved request is unpaid, uses a deferred payment choice and reserves no preparation tasks. It is displayed as awaiting confirmation rather than a guaranteed booking. Once the owner confirms a workable plan, the customer chooses an available payment method from that saved order. Repeating a valid payment-choice request returns the same selection; the selection itself does not charge funds or change the price.

Cash is offered only as Cash at collection. New delivery orders cannot select cash on delivery, including by forging a hidden field. Manual bank/DuitNow payment appears when configured and is verified externally by the owner. PayPal is a Sandbox integration with a visible test-funds note; optional delivery escrow uses Sepolia. These separate mechanisms do not make every submitted preorder paid.

### 4.3.6 MY ORDERS, AMENDMENTS AND REVIEWS

My orders separates Current, History and All with private counts. The API returns at most ten records per page and a descending-ID cursor. Load more appends older records; refresh replaces the current page. New insertions do not shift the older cursor, and an interrupted append can retry without duplicating rows. A failed refresh hides potentially stale actions. The interface distinguishes the accepted delivery time/window, kitchen stage, payment status, courier reference and reminder preferences.

@figure screen-orders | Figure 4.7: Customer order cards, private filters and payment/fulfilment separation (local test records).

Changes to delivery use a preview-and-confirm workflow with current eligibility checks. Started, consumed, refunded or invoice-locked arrangements can require owner resolution instead of silently changing a reservation. When an unscheduled request changes time, it remains unconfirmed unless the operation also confirms a valid plan. The existing order is amended; a date edit is not a new payment or fabricated completion.

Customers can leave a bounded rating/comment only when an eligible delivered order contains the menu. Reviews are not invented to make the storefront appear active. Courier information is kitchen-entered; customers can open its saved public tracking link and contact the kitchen. A scheduled minute is an agreed arrangement, not a verified live courier ETA.

## 4.4 OWNER INTERFACES

### 4.4.1 MENUS, CATEGORIES AND PHOTO UPLOADS

Menu management combines status, price, recipe, preparation settings and selling details. The owner can create and edit categories, create a menu, pause ordering and archive a retired offer. Deletion is subject to current commitment/history safeguards; archival preserves records needed for old orders. Required price/category errors are associated with the form instead of being shown as duplicate, unstructured messages.

@figure screen-menus | Figure 4.8: Owner menu list with price, recipe and lifecycle actions (local test catalogue).

A selling unit can be a meal, box, pack or other documented unit. Optional serving guidance is descriptive. Fixed box contents are shown without assuming flavour substitutions. Sizes can be separate products with independent prices and recipes, connected by a size group. Sale dates, weekdays and a cutoff can be set per menu. The cutoff does not replace lead time: 24 hours of notice means 24 hours before preparation starts, plus cooking and any travel buffer before handover.

@figure screen-menu-editor | Figure 4.9: Menu editor with selling details and progressive recipe/preparation settings (local unsaved form).

Photos support public URLs and local file upload. The upload endpoint requires staff permission and CSRF. It decodes still JPEG, PNG or WebP input up to 4 MiB, rejects malformed/animated/oversized images, applies orientation, removes metadata and re-encodes at most 1600-pixel WebP within 512 KiB. Sanitised content is deduplicated by SHA-256 and stored in PostgreSQL through MenuPhoto. This persists across Vercel deployments without relying on its temporary filesystem. Uploading is public menu-media publication, not private file storage. An upload cancelled before menu save can remain unreferenced; storage maintenance is a separate concern.

### 4.4.2 INGREDIENT DIRECTORY AND INVENTORY

The ingredient directory records each raw material’s native unit and optional estimated unit cost. Reusable storage guidance can contain documented storage type, days from receipt, source and matching conditions. It is optional rather than a compulsory prerequisite to receiving stock. The owner can enter batch-specific documented guidance when no suitable material reference exists. A chilled reference is not offered as a frozen reference, and editing guidance does not revise previously recorded batch evidence automatically.

@figure screen-inventory | Figure 4.10: Inventory overview, held/dated stock and batch review (local test records).

The batch form supports three expiry modes. Printed expiry/best-before records the supplier’s date and its meaning. Manufacture date plus documented shelf life uses the production date as the calculation start. Received date plus documented storage life supports suitable unlabelled ingredients, including wet-market purchases, where evidence matches the ingredient’s actual condition. Purchase source is contextual evidence; selecting Wet market does not magically provide a safe duration. The FoodSafety.gov cold-food storage chart is a reference to read, not an automatically verified supplier label (FoodSafety.gov, n.d.).

| Recorded field | Meaning | Effect on the batch |
| --- | --- | --- |
| Received date | When the kitchen received this batch | Receipt-based start and future-receipt eligibility |
| Manufacture date | When the ingredient/product was produced | Start for manufacture-plus-life mode |
| Printed deadline | Supplier use-by/expiry or quality best-before date | A recorded allocation deadline; not the manufacturing date |
| Documented shelf/storage days | Applicable whole-calendar-day duration with source/conditions | Calculates a planning deadline in the chosen mode |
| Opened/thawed pair | Relevant date and documented permitted days | Can impose an earlier deadline |
| Handling history and hold | Evidence of uncertainty or breach | Uncertain/breached stock is held and excluded |
| Storage location | Physical kitchen location such as Fridge A, top shelf | Helps locate the batch; does not prove temperature compliance |

@figure screen-expiry-evidence | Figure 4.11: Received-date calculation for an unlabelled ingredient; owner-supplied evidence is required (unsaved local form).

Quantity edits require a reason and the current record version. Receipts, adjustments, holds, deletion and waste maintain the relevant audit evidence. Batch IDs identify deliveries, not menu IDs. Historical fictional stock remains test evidence even when its storage-location text is changed to a plausible shelf. A realistic location must not be treated as a verified physical stock count.

### 4.4.3 PLANNER, MULTI-DAY WORK AND CLOSURES

Planner separates accepted scheduled work from delivery requests, orders needing plan review and past-due follow-up. A pending order can already have a reserved plan; pending does not mean absent from the planner. Moving it to processing is optional progress recording, not a compulsory acceptance step for an automatically scheduled booking. An unconfirmed request has no reserved tasks and must be reviewed explicitly.

@figure screen-planner | Figure 4.12: Planner with dated work, review queues and kitchen availability (local test date).

For a valid future delivery, Calculate plan derives each step’s start and finish from accepted recipes and constraints. Preview shows a schedule before confirmation. Use current recipe and preparation settings is explicit because a recipe edit should not silently alter the accepted ingredients. A later delivery can be confirmed together with its new valid plan. A signed preview expires after ten minutes and rejects changes to the order or kitchen availability.

Preparation can span multiple days when its settings permit it. The scheduler distinguishes permitted gaps between steps, allowed overnight unattended fridge/rest work, independent repeated batches and explicitly splittable attended work. Splittable work is limited to supported preparation/packing/no-equipment tasks with a positive maximum pause and a permitted pause-storage resource. Cooking and unattended steps cannot simply be interrupted to make a schedule fit. Documented recipe handling limits, not merely a larger day count, determine what is valid.

Kitchen hours apply to preparation. Delivery and collection have their own configured hours. Therefore work after a delivery closing time can prepare a later order if the menu’s preparation span and finishing rules allow it. A delivery after kitchen closing can also be feasible if cooking completes within kitchen hours and the accepted travel/finish rules fit. These are independent windows; neither authorises arbitrary unsafe holding. A zero early-finish allowance uses a flexible same-dispatch-day finishing window rather than forcing every menu to finish at exactly the same minute.

Kitchen availability can block closures, breaks or delivery runs. A block reserves the whole kitchen, including otherwise unattended resources. The owner should record their own driving time if it removes the sole worker from cooking. The manual arrangement path is an advanced override with a reason and review: a continuous whole-kitchen reservation can include overnight gaps and does not retain a detailed automatic step plan. It is not equivalent to an automatically verified safe process.

### 4.4.4 SHARED COOKING, PACKING AND GROUPED HANDOVER

Shared cooking explicitly combines compatible confirmed, future, pending single-menu orders. The initial implementation requires identical product identity, accepted recipe/preparation/selling settings, delivery instant and dispatch buffer. A preview compares reservations for 2–10 orders. Confirmation locks the kitchen and saves a common reservation reference, counted once in calendar/availability views. It does not merge customers, payments, accepted ingredient deductions or delivery records.

Calendar export provides individual preparation tasks and deliveries; it should be re-exported after a plan changes and is not a live calendar subscription.

The daily handover view groups confirmed work by Malaysia date/hour and fulfilment. Packing lists retain each customer’s accepted quantities and instructions. Up to 20 eligible orders can be selected for food-ready, dispatch or delivered/collected confirmation. The server checks actual eligibility and edit versions and applies the group atomically. An error leaves the selected group unchanged. Ready deducts ingredients once; dispatch can queue opted-in updates; delivered means an actual handover confirmed by the owner.

This reduces repeated status administration for a small operator without pretending to know events the system cannot observe. Preparing and dispatch are optional intermediate steps. A timer may identify overdue follow-up, but it cannot prove that a rider collected the food or that a buyer received it. Collection cannot be marked out for delivery. Payment remains independent of every physical stage.

### 4.4.5 COURIER AND CUSTOMER COORDINATION

The owner books and pays/arranges the rider through the courier’s normal service, then can record carrier name, reference, link and contact information against the website order. Appropriate recipient details and a WhatsApp contact draft reduce transcription effort. Customer instructions specify the agreed contact/handover arrangement. A customer may still be unavailable or a rider may be early/late; email and saved details assist coordination but do not guarantee reception or authorise leaving perishable food unattended.

There is no connected GrabExpress booking/tracking API and no verified webhook that automatically updates website delivery status. This is an explicit scope boundary, not an invisible integration that should be claimed in the report. The existing design can support a future documented adapter, but API access, regional testing and provider events would need independent implementation and verification. The current website remains usable without that extension.

### 4.4.6 SALES, COSTS AND RECORDED CONTRIBUTION

Sales views show defined order/sales cohorts, menu quantities, trends and recommendation engagement. The source/date basis matters: the contribution view groups by order placement date, while demand forecasts use delivery history with labelled fallbacks. Menu line revenue, discounted order food revenue and delivery fees are not interchangeable. Filters and CSV exports disclose what range and number of records they include.

@figure screen-reports | Figure 4.13: Owner analytics with distinct sales and evidence-based report tabs (local test data).

Current recipe estimates multiply ingredient requirements by estimated unit costs and add packaging. Price/bulk-offer scenarios compare a hypothetical price, discount, ingredient increase and additional entered costs. Recorded order contribution instead requires accepted recipe quantities, actual consumption matched to those quantities, known batch purchase costs, accepted packaging and an eligible realised outcome. Synthetic sales summaries intentionally lack real cooking/consumption transactions, so they may provide demand history while contribution remains unavailable.

A missing contribution is therefore not an arithmetic failure or RM0. It means the evidence needed to compute it is absent or incomplete. A completed, calculated zero or negative result is retained. At the current implementation boundary, food contribution excludes delivery income/cost, payment fees, labour and overhead unless a specific scenario includes entered assumptions. It is not net profit or audited financial accounting.

The system also records operating expenses and actual waste with request IDs, quantity bounds and voiding/correction workflows where supported. Disposal is a stock-changing event; a FreshCast forecast is not. A cancelled order does not automatically refund money or restore already consumed ingredients.

### 4.4.7 SETTINGS AND OPERATIONAL CHECKS

Settings provides kitchen hours, public identity/story, contact details, collection/delivery choices, fees, payment instructions, setup checks and email diagnostics. Technical diagnostics and recovery controls use progressive disclosure so routine owner tasks are not dominated by environment-variable names. Forms distinguish short delivery-area choices from the narrative service-area description and the public collection address.

@figure screen-settings | Figure 4.14: Owner Settings and focused configuration sections (local test settings).

During save, dependent controls are disabled to avoid editing values that an eventual response would replace. A failed save keeps the draft and offers another save rather than a destructive reload. An initial read failure offers a read retry. Existing order schedules and accepted fees remain snapshots rather than being retrospectively replaced by new defaults.

Setup checks describe recorded configuration such as recipes, cooking steps and costs; they do not certify food safety, production readiness or email inbox receipt. Backup controls link source/model recovery separately from private kitchen data. Changing a UI label does not itself change old database rows, and a Git push does not prove the production deployment is Ready.

## 4.5 KEY CALCULATIONS AND TRANSACTION RULES

### 4.5.1 EFFECTIVE DEADLINE AND REMAINING WINDOW

For manufacture mode, the base deadline is manufacture date plus documented shelf-life days. For receipt mode, it is received date plus documented storage-life days. For printed mode, it is the entered printed deadline. Applicable original printed, opened-plus-days and thawed-plus-days limits can only shorten the effective deadline. In notation, E = minimum of the valid applicable deadlines. Uncertain handling or a known storage breach holds the lot independently of E.

For an assessable non-empty received lot, the displayed remaining-window indicator is bounded between 0 and 100: R = 100 × (E − today) / (E − S), where S is manufacture date for manufacture mode and receipt date otherwise. The code reports unknown when an appropriate denominator or required evidence is missing. Expired/held batches contribute zero to the aggregate; unknowns are separately counted. The aggregate is an equal-weight mean over assessed batches, not a quantity-weighted measure of physical freshness. Stock dated today can still be eligible through that calendar day even though its remaining-window percentage is zero.

This implementation meets the record-monitoring aspect of Objective 2 without claiming a laboratory result. It does not detect temperature excursions, pathogens or food safety from appearance. Calendar-day guidance cannot be silently substituted for a short hourly holding rule. Owners remain responsible for applying reliable ingredient-specific guidance and actual conditions.

### 4.5.2 CURRENT PORTIONS, FUTURE CAPACITY AND FEFO

For a current recipe with eligible quantities Qᵢ and per-selling-unit requirements rᵢ, current possible units are the floor of the smallest Qᵢ/rᵢ ratio. Missing or invalid recipes do not create fictitious stock. Stock eligibility excludes non-positive, held, already-expired and future-receipt lots. This is an ingredient quantity calculation, separate from a date’s labour/equipment capacity or future procurement.

At food-ready confirmation, required quantity for ingredient i is accepted quantity per unit times ordered units. The server locks and consumes usable batches in earliest-expiry order, records per-batch consumption and cost evidence, and sets inventory_deducted. A shortage rolls the transaction back. Planning allocations and scenarios are read-only; they must not decrement batches in advance or deduct the same lot for two hypothetical requirements within one calculation.

### 4.5.3 PREPARATION WORK AND RESOURCE FIT

Batch count is ceiling(ordered selling units / accepted batch size). In combined mode, each step’s duration is base duration plus (batches − 1) times its additional-batch duration. Independent mode represents repeated runs rather than simply inflating one uninterrupted cooking step. Explicit task order, resource, hands-on flag, permitted waits/pauses and overnight permission define the schedule.

Total step time is not elapsed window or worker load. Unattended steps can overlap other resources, while one worker cannot perform two hands-on tasks together. The conservative greedy backward search may reject a feasible arrangement a human could find; it is not a proof of optimal scheduling. Existing bookings remain fixed unless an authorised reviewed amendment changes them.

For the starter banana-cake settings, ten boxes imply three batches. The six step durations total 540 minutes, with 180 hands-on minutes. The 8:00–20:00 kitchen window is 720 minutes, so the example warning is not simply nine hours exceeding twelve. The daily selling limit is eight boxes. The preview now begins at a quantity within that cap and numerically explains an explicitly larger sample. Reducing its preview quantity does not change the menu’s daily limit or book a real slot.

### 4.5.4 PRICES, PAYMENT AND ACTUAL CONTRIBUTION

Let F be the sum of accepted unit prices times quantities, D the applicable food discount and H the accepted delivery fee. The payable amount is F − D + H. Order.total_amount is discounted food value; shipping_fee is stored separately. Client totals are not trusted. PaymentEvent records external/manual evidence, including completed, pending and failed outcomes. A unique request ID and provider reference checks support safe replay.

For a complete realised delivered-paid order, recorded food contribution is discounted food revenue minus actual batch ingredient cost minus accepted packaging estimate. Cooked cancellations and refunds have their defined revenue treatment. Missing consumption, missing costs or unpaid delivery can make the value unavailable. Current recipe scenarios cannot reconstruct those historical facts.

## 4.6 FRESHCAST AND FORECASTING IMPLEMENTATION

### 4.6.1 THREE DATA SOURCES AND THEIR PURPOSES

@figure screen-freshcast | Figure 4.15: Kitchen FreshCast decision assistant with source and evidence labels (local scenario).

| Source | Demand and inventory basis | Appropriate interpretation |
| --- | --- | --- |
| My kitchen | Database orders, accepted recipes and dated ingredient batches; local menu forecasts | Kitchen-specific decision support, with generated-history warnings where applicable |
| Genpact | External weekly centre/meal data and saved CatBoost artifact; explicit simulated operational CSVs | External ML demonstration, not a trained predictor for the kitchen’s named dishes |
| Fixed illustrative walkthrough | Frontend fixtures with predefined quantities and actions | Model-free explanation/tutorial; no database or failed-API fallback |

The interfaces share a decision structure but retain source-specific controls and chart units. Genpact uses centres, meal IDs and weeks; local kitchen uses dates, named menus, native ingredient units and accepted bookings. A fixed sample is useful for explaining the journey without external dependencies, but it must remain labelled and optional. Its inputs do not validate predictive accuracy.

### 4.6.2 LOCAL MENU AND AGGREGATE FORECASTS

The current per-menu decision path in kitchen_decisions.py uses paid, delivered historical portions, delivery dates and current menu identity checks. Historical renamed menus are excluded rather than assigning their past sales to a different recipe. Missing delivery dates use explicitly identified reporting fallbacks. Absent days mean zero recorded sales, not verified zero latent demand. Generated history remains marked as generated evidence.

Candidate daily methods are a trailing 28-day mean, trailing seven-day mean and same-weekday average. With at least 42 recorded calendar days, the last 28 days are split into 14 validation and 14 test days. Methods are selected using validation MAE; the held-out test is reported separately. Forward planning recursively uses predicted values inside a future window. A separate full-window diagnostic avoids describing rolling one-day predictions as demonstrated multi-day accuracy. Sparse history uses a limited baseline rather than inventing a confidence interval.

Known future commitments are subtracted from total forecast demand before speculative needs are added. Plannable extra portions are constrained by current recipes, offered dates, cutoffs, lead notice and daily limits. Forecast portions become ingredient quantities through recipes and conservative dated stock allocation. Low/high sensitivity cases vary demand by error/limited-history assumptions; they are not statistical confidence intervals. Detailed tracing connects menu portions to ingredient need, batch use, uncovered need and unused eligible stock at expiry.

A separate aggregate weekly kitchen_forecast.py comparison can fit ridge autoregression using lag1, lag2 and rolling-four-week features, alongside last-week and moving-average baselines. Its chronological train/validation/test split and refit are distinct from per-menu decision forecasting. The simpler sales-summary estimator in forecast.py is another reporting baseline. Consequently, the report does not state that every kitchen prediction is CatBoost or that no kitchen routine ever fits coefficients. The deployed per-menu decision logic is a local statistical forecasting process; it does not require the external Genpact training dataset.

### 4.6.3 GENPACT CATBOOST MODEL

The saved external CatBoost model (Prokhorenkova et al., 2018) uses 456,548 historical rows from 77 centres. Source tables join weekly meal demand with meal category/cuisine and centre metadata. Features include centre/meal identity, prices, promotion flags, area, earlier demand lags, a shifted four-observation mean and the interval since the last observation. Shifted features use only earlier observations at each target week.

The training script uses CatBoostRegressor with 200 iterations, depth 6, learning rate 0.08, RMSE loss and seed 42, fitting log(1 + demand). Predictions are transformed back with expm1 and bounded below by zero. Training uses eligible weeks through 135; the saved rolling one-step holdout covers weeks 136–145. The artifact was restored and independently re-evaluated for the 29 October recovery evidence; no retraining was performed for this report. Its reproduced WAPE is discussed in Chapter 5 and is not a kitchen-customer accuracy result.

The operational recipes, batches and supplier inputs for the Genpact view are explicitly simulated. Model meal IDs are not matched to Product IDs merely because both are integers. Changing a promotion flag produces an associational what-if, not measured campaign uplift. Unsupported operational centres fail explicitly instead of silently receiving invented inventory.

### 4.6.4 EXPIRY RISK, ACTIONS AND FOLLOW-UP

An expiring batch’s projected unused quantity equals eligible starting stock minus confirmed allocation minus additional forecast use before its deadline, bounded below by zero. A batch expiring later carries its remaining stock beyond the current window. Dated shortages and expiry surpluses can coexist: sufficient total stock does not mean it arrives before the demand or survives until it is needed. Zero projected waste can therefore accompany an uncovered demand gap.

FreshCast offers reviewable action comparisons, including preparation/menu review, monitoring and a hypothetical purchase with arrival, expiry, quantity and optional cost. A comparison uses a common baseline and preserves source labels. It does not actually buy stock, publish promotions, change orders or promise savings. Signed decision snapshots and browser-held follow-up notes help relate later outcomes to an earlier scenario; browser storage can be cleared, and recorded outcomes are not causal proof that a recommendation saved money or prevented waste.

## 4.7 PAYMENTS AND ASSISTED ORDERING

PayPal Sandbox follows an order/capture interface (PayPal, n.d.) and supports saved provider order creation, buyer approval, server capture verification, order-bound payment records and recoverable status checking. The interface uses PayPal as the primary label with an explicit test-payment note. Webhook verification and owner checks support reconciliation when configured; a browser approval flag cannot create a completed payment. Live-money merchant activation and live refund reconciliation are separate deployment/business work.

Order-bound escrow uses Sepolia only when the server configuration is complete. Its invoice binds a random reference, contract, buyer/seller/arbiter, MYR record, configured test-wei amount, dispatch deadline and minimum confirmations. The server verifies funding independently over JSON-RPC and writes one ledger receipt or an observed refund event. It does not hold private keys. The separate wallet tool and generated demo-credit balance remain demonstrations, not funded bank accounts. A public-chain production escrow service would require independent contract/security and legal review.

Kitchen Help provides approved topic answers in supported languages and can use an optional bounded AI classifier. The Plan an order assistant extracts limited fields, presents proposals and uses authenticated basket/checkout tools. It does not gain arbitrary SQL or unrestricted authority to mark paid, invent availability or silently place a customer order. Fixed approved answers and bounded actions reduce hallucinated policy or payment instructions; external model failure has a local recovery path.

## 4.8 EMAIL REMINDERS, RECOVERY AND DEPLOYMENT

One authenticated worker serves the owner and all opted-in customers. The owner’s preparation/delivery reminders cover eligible open events within 24 hours, including overdue events up to 24 hours. Customer advance reminders become eligible within two hours before the agreed time or arrival-window start and require confirmed preparation plus consent. Dispatch and agreed-time updates are separate choices. At most three emails are attempted per call, with room for owner work; the worker prioritises the defined customer-update queues.

The GitHub Actions workflow declares a five-minute schedule and is enabled by a repository variable with a private worker secret matching the server. A five-minute poll does not send the same reminder every five minutes: successful event receipts suppress routine repeats. A schedule can be delayed; a successful manual run does not prove automatic cadence. SMTP acceptance is not inbox receipt, and a crash between SMTP acceptance and saving its receipt can still produce a duplicate retry. Settings exposes current run/queue diagnostics and an owner test-email action separately from a normal status refresh.

Website code, the Genpact runtime archive and private kitchen data require different backups. GitHub source does not contain the persistent database or automatically include a Release asset. The saved model archive has a recorded SHA-256 for recovery; uploaded menu photos are part of the private PostgreSQL backup. The release build checks for pending migrations rather than automatically mutating production schema. Credentials and backups containing customer information do not belong in the public repository.

## 4.9 INTERFACE AND ACCESSIBILITY PRINCIPLES

The visual references supplied during development informed compact food cards, prominent but limited primary actions, readable grouping, sticky basket access and clear progress. They were used as design inspiration rather than copied screens or proof of usability. Nielsen’s visibility, consistency, error prevention and recovery principles support showing the actual basket quantity, distinguishing waiting requests from bookings, retaining failed-save drafts and preventing duplicate submission (Nielsen, 1994).

Progressive disclosure groups optional contact, recipe and technical details without hiding the next required action. Semantic form labels, keyboard focus and native dialogs support access. Automated Axe checks used WCAG A/AA-related rules in selected desktop, tablet and phone states; this is partial verification against accessibility concerns, not complete WCAG conformance certification (W3C, 2023). Table detail and graph units remain explicit where simplification would lose evidence.

Success popups close after four seconds, information after six and errors after ten; hover/focus can pause them. Persistent inline form errors are retained where needed for correction. A cart success starts after its refresh, and a successful write with failed read uses truthful recovery. This prevents notifications from disappearing while an action still appears busy and avoids forcing the owner to dismiss every routine confirmation.

@figure screen-menu-mobile | Figure 4.16: Phone menu with compact navigation, food cards and basket access (390-pixel local viewport).

## 4.10 CONCLUSION

The implemented interfaces support the five objectives through a coherent chain: branded discovery, constrained suggestions, authoritative checkout, accepted order evidence, reviewable preparation, dated stock and actual fulfilment. Supporting payment, reminder and forecasting features preserve their external boundaries. The following chapter evaluates these behaviours using repeatable tests and explains which practical outcomes still need validation with intended users.
