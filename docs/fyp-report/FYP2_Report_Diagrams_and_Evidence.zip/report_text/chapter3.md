# CHAPTER 3 — METHODOLOGY AND SYSTEM DESIGN

## 3.1 INTRODUCTION

This chapter retains the project’s iterative Agile approach and updates the design to the implemented Dapur Kita system at revision ab1a976 (29 October 2026). The five objectives in Section 1.3 remain unchanged. The diagrams distinguish customer and owner actions from external payment, email and forecasting services. A use case describes an observable user goal; an activity diagram describes decisions in a workflow; a sequence diagram identifies time-ordered component messages; and class and entity–relationship diagrams describe domain responsibilities and persistent relationships (Sommerville, 2016).

The implementation uses Django’s Product model for the menu entity. RawMaterial identifies a measured ingredient, ProductIngredient is the current recipe junction, and InventoryItem identifies an individual received batch. OrderIngredient and preparation snapshots preserve what was accepted for an order. SalesReport is not a database model: reports are calculated views of recorded transactions. The design therefore avoids the earlier diagram’s implication that a separate SalesReport entity stores all analytics.

## 3.2 AGILE METHODOLOGY

Development was organised into repeated requirements, design, implementation, verification and refinement cycles. This is an individual, Agile-inspired project rather than a claim that a fully staffed Scrum team conducted formal ceremonies. The approach follows the Agile emphasis on working software and responsiveness to change described in Chapter 2 (Beck et al., 2001). Feedback raised during development was converted into bounded changes and checked before release.

The implementation history includes refinement of automatic scheduling, separation of unconfirmed requests from accepted plans, expiry evidence, current and historical cost calculations, recommendation budgets, payment verification and responsive layouts. These changes illustrate iterative development: an early solution was tested against a concrete scenario, its limitation was identified, and its behaviour was revised while preserving accepted order history.

| Development increment | Implemented output | Verification evidence |
| --- | --- | --- |
| Foundation and storefront | Customer accounts, categories, branded catalogue, basket and saved addresses | Authentication, permissions, cart and address tests |
| Preorder and operational planning | Accepted recipe/settings snapshots, resource scheduling, closures and replanning | Planning, fulfilment, multiday and concurrent-booking tests |
| Freshness and traceability | Evidence-based batch dates, holds, FEFO, consumption and waste records | Freshness, inventory audit and PostgreSQL stock-locking checks |
| Decision support | Sales/cost reports, recommendations, whole-order finder and FreshCast | Financial, recommendation, source separation and model API checks |
| External boundaries | PayPal Sandbox, order-bound Sepolia escrow and opt-in SMTP reminders | Verification, retry, ownership, worker and mocked-provider checks |
| Usability refinement | Compact food cards, daily handover queues, timed feedback and bounded history | Responsive Chromium checks and frontend regression suites |

The Gantt chart in Chapter 1 remains the original proposal plan. This increment table describes implemented work and does not manufacture consultation dates or attendance. Supervisor consultations must be documented using the institution’s actual logbook.

## 3.3 USE CASE DIAGRAMS

The two views below share one system boundary and divide it by user role for readability. Visitors can browse and request general suggestions without becoming staff. Customers authenticate to maintain a persistent basket, place orders and access their own records. The kitchen owner uses staff-authorised APIs to manage business data. Payment providers and the email scheduler are supporting external systems; the courier is coordinated outside the application.

@figure usecase-customer | Figure 3.1: Customer and visitor use cases.

@figure usecase-owner | Figure 3.2: Owner and integration use cases.

The include relationship means checkout always checks fulfilment and the requested date/time. Payment is a separate goal because an unconfirmed review request is saved unpaid and chooses payment only after a workable preparation plan is accepted. Recommendations are optional assistance to browsing. No courier API actor is drawn because the current application does not subscribe to verified courier events.

## 3.4 USE CASE SCENARIOS

The original UC-01 to UC-19 identifiers are retained so that earlier analysis can still be traced to the implementation. Their conditions and outcomes are corrected where the system has evolved. UC-20 to UC-30 cover the supporting features added during implementation. A saved request, a confirmed booking, a payment and an inventory deduction are different outcomes.

@usecases

## 3.5 ACTIVITY DIAGRAMS

### 3.5.1 PREORDER CHECKOUT AND REQUEST REVIEW

The checkout activity includes both the automatically scheduled path and the explicit kitchen-review path. A future request can be recorded without a feasible automatic plan, but it must not be displayed as a reserved cooking slot or successful payment. Sale dates, cutoffs, future-date bounds and fulfilment rules are still validated. A customer must not be repeatedly asked to guess unavailable times: the optional basket preview and checkout search present feasible alternatives when available.

@figure activity-checkout | Figure 3.3: Preorder checkout with confirmed and unconfirmed paths.

### 3.5.2 BATCH DATES AND FRESHNESS

The owner chooses the evidence supporting the deadline rather than having the system invent a universal shelf life. Receipt date records when the batch reached the kitchen. Manufacture date records production; it is not the printed use-by date. A printed best-before date is a quality reference, while a use-by/expiry date is treated as a deadline. The application conservatively treats every recorded effective deadline as an allocation limit. Actual conditions and earlier opened/thawed limits can shorten it.

@figure activity-freshness | Figure 3.4: Inventory evidence, effective deadline and handling hold.

### 3.5.3 PREPARATION PLANNING AND REPLANNING

The scheduler calculates a start and end; the owner need not guess an automatic end time. Earlier preparation is permitted only within the accepted preparation span and documented step waits, pauses and finishing allowances. Review precedes confirmation. A changed order, closure or booking invalidates a stale preview rather than silently moving someone else’s work.

@figure activity-planner | Figure 3.5: Calculation and confirmation of an order preparation plan.

### 3.5.4 ACTUAL PROGRESS AND HANDOVER

Preparing and out-for-delivery are optional intermediate updates. The owner confirms actual food readiness before collection or delivery. A grouped operation validates every selected order before applying any change, so a failed member cannot leave a partially updated group. Payment is recorded independently from physical handover.

@figure activity-fulfilment | Figure 3.6: Grouped food-readiness and actual handover activity.

## 3.6 SEQUENCE DIAGRAMS

The earlier sequence diagrams are consolidated into related interactions to avoid duplicating identical list/create operations. Browse and recommendation correspond to UC-01/02; basket to UC-03; quote and placement to UC-04/05/06; payment to UC-07; paginated order reading to UC-08; protected menu/ingredient CRUD to UC-09–14; evidence and FEFO to UC-13–17; reporting to UC-18/19; and the remaining interactions to UC-20–30. Each diagram is an implementation-level collaboration, not a claim that the browser can directly update database or payment state.

### 3.6.1 MENU DISCOVERY AND GUIDED RECOMMENDATION

@figure sequence-discovery | Figure 3.7: Explainable discovery and whole-order date guidance.

The server ranks eligible menu candidates and checks complete candidate baskets. A RecommendationSession binds displayed products and context to later events. Guest discovery is allowed; applying a durable basket change requires the authenticated customer and a fresh, matching search context. The final three suggestions are alternatives, not three orders automatically combined.

### 3.6.2 BASKET MUTATION AND FEEDBACK

@figure sequence-basket | Figure 3.8: Basket mutation, refresh and timed confirmation.

A confirmed write followed by a failed read must not be described as a failed addition. The interface explains that the item was saved and offers a basket refresh, avoiding an unintended duplicate addition. Repeated quantity changes receive distinct notifications. Stale responses from a previous account session are discarded.

### 3.6.3 QUOTE AND ORDER PLACEMENT

@figure sequence-checkout | Figure 3.9: Authoritative quote and retry-safe placement.

Checkout prices, discounts and delivery fees are recomputed on the server. A unique checkout request identifier supports recovery after a lost response. The saved order retains line prices, names, accepted ingredient quantities, preparation settings, delivery-address details and fulfilment terms. The basket is not itself a reservation, and placement does not deduct ingredient stock.

### 3.6.4 PAYPAL PAYMENT VERIFICATION

@figure sequence-paypal | Figure 3.10: Server-verified PayPal Sandbox payment.

Provider confirmation must match the order and expected MYR amount. The displayed payment state comes from server verification and a durable ledger event, not a client-supplied paid flag. The main interface may say PayPal, but the test-funds disclosure remains necessary. The application does not represent Sandbox capture as real customer revenue.

### 3.6.5 PREPARATION PREVIEW AND CONFIRMATION

@figure sequence-replan | Figure 3.11: Replanning with a signed, expiring preview.

The same-delivery recalculation can use accepted settings; adopting current recipes/settings is explicit. When delivery is changed, the server rechecks the new arrangement. A preview is not a saved reservation. The owner confirms a proposal within its ten-minute validity period, and current locked state must still match.

### 3.6.6 INGREDIENT DEDUCTION AND GROUPED PROGRESS

@figure sequence-fefo | Figure 3.12: FEFO deduction and all-or-nothing progress updates.

The operation uses accepted OrderIngredient quantities. It locks the union of relevant stock rows in a consistent material/expiry/receipt/ID order and consumes eligible batches by earliest expiry. IngredientConsumption records carry batch cost and identity evidence; InventoryLog records quantity changes. Any shortage aborts the transaction. Repeating food-ready after inventory_deducted is true does not consume the ingredients again.

### 3.6.7 INVENTORY EVIDENCE AND VERSION CONFLICTS

@figure sequence-inventory | Figure 3.13: Recording batch evidence without overwriting a newer edit.

An optimistic edit version prevents a previously opened form from restoring stock that has since been consumed or adjusted. Matching material guidance is copied into the unsaved form only after owner selection. Its subsequent amendment does not retrospectively change older batches.

### 3.6.8 SALES AND FINANCIAL EVIDENCE

@figure sequence-analytics | Figure 3.14: Sales and recorded contribution reporting.

The report response includes definitions, unavailable values and exclusions. A price scenario estimates costs using current recipes, while recorded contribution needs actual consumption and accepted packaging evidence. CSV export checks its date range and size and escapes spreadsheet-formula text.

### 3.6.9 FRESHCAST SOURCE SEPARATION

@figure sequence-freshcast | Figure 3.15: Source-labelled forecasts and read-only scenarios.

The database kitchen path, external Genpact path and fixed illustrative walkthrough must not be silently interchanged. Genpact meal IDs are not local product IDs. The kitchen decision view adjusts speculative demand for known commitments before allocating remaining eligible stock. Scenario comparisons do not purchase, dispose of or deduct stock.

### 3.6.10 EMAIL REMINDERS

@figure sequence-reminders | Figure 3.16: One authenticated worker for owner and opted-in customer emails.

Customer advance reminders require a valid account email, per-order consent and confirmed preparation. Separate choices control dispatch and agreed-time updates. Event receipts suppress routine duplicates, while provider acceptance is distinct from inbox delivery. Phone numbers support contact and WhatsApp drafts; they are not SMTP recipients or an automatic WhatsApp subscription.

### 3.6.11 ORDER-BOUND ESCROW

@figure sequence-escrow | Figure 3.17: Sepolia escrow invoice and independent funding verification.

The invoice fixes chain, contract, participants, value, reference and dispatch deadline. The browser wallet signs the transaction. Django stores the submitted hash for recovery and independently verifies canonical receipt, transaction, event, runtime code and confirmed contract state. An unpaid or pending transaction cannot be promoted to paid by a browser message. Escrow state does not autonomously mark food prepared or delivered.

## 3.7 CLASS DIAGRAM

@figure class-domain | Figure 3.18: Core domain classes and service-module responsibilities.

The diagram uses actual model names. Services are explicitly stereotyped because scheduling and order_progress are Python modules rather than persistent entity tables. User-facing menu wording maps to Product. The full field inventory in Appendix D complements this selected domain view; the entity diagrams below describe foreign-key relationships rather than every method in the codebase.

## 3.8 ENTITY–RELATIONSHIP DIAGRAMS

The database design is divided into four views so that cardinalities and audit relationships remain readable. PK denotes a primary key; FK denotes a foreign key. A nullable child FK means the child can reference zero or one parent. A parent can have zero or many children unless the annotation says one-to-one. JSON snapshots intentionally preserve accepted terms and are not additional relational entities. Django’s built-in authentication, session and migration tables are outside these application-domain views.

### 3.8.1 COMMERCE AND ORDER HISTORY

@figure erd-commerce | Figure 3.19: Commerce, basket, addresses and order-line ERD.

Deleting an address does not erase the order’s accepted address snapshot. Product references in old OrderItem rows can be null while the accepted product name and price remain available. The current menu lifecycle protects relevant commitments and supports archival; a diagram must not imply that all history should be renumbered or deleted when a menu is retired.

### 3.8.2 RECIPES, DATED BATCHES AND ACTUAL CONSUMPTION

@figure erd-inventory | Figure 3.20: Current recipes, accepted recipes, stock and consumption ERD.

ProductIngredient describes the current recipe; OrderIngredient is the accepted recipe for one order item. IngredientConsumption links that item to the batches actually used and preserves unit-cost/date evidence. This supports tracing a batch into orders and calculating contribution only when its inputs are complete. InventoryLog and WasteRecord serve different audit purposes and must not be treated as interchangeable deductions.

### 3.8.3 OPERATIONS AND PAYMENT RECORDS

@figure erd-operations | Figure 3.21: Operational settings, amendments, reminders and payments ERD.

OrderReminder has one receipt per order/event key. PaymentEvent records receipt/refund evidence with a unique request ID; its optional resolves relation links a resolution to an earlier event. Storefront is treated as a single business configuration by the application, not a multi-tenant marketplace. KitchenBlock is a global time interval; its effects are calculated without an Order FK. OperatingExpense is an independent dated expense record.

### 3.8.4 ENGAGEMENT AND SUPPORTING RECORDS

@figure erd-engagement | Figure 3.22: Reviews, recommendation telemetry, menu photos and attempt limits.

MenuPhoto is content-addressed by a digest and stores sanitised WebP bytes. Product.image_url is a string that can point to its public route or an external image; it is not a MenuPhoto FK. RecommendationSession uses a hashed owner key instead of a User FK. AuthAttempt stores hashed rate-limit identities, not passwords. These distinctions prevent the conceptual ERD from inventing relationships that the schema does not enforce.

## 3.9 REQUIREMENT TRACEABILITY AND DESIGN LIMITS

| Objective | Principal user goals | Persistent evidence | Implementation boundary |
| --- | --- | --- | --- |
| 1. Flexible date-based preordering | UC-03–08, UC-21, UC-24/25 | Order, accepted snapshots, amendments and shared task reservations | Bounded deterministic planner; a request can remain unconfirmed |
| 2. Shelf-life/storage monitoring | UC-11–15, UC-17/28 | Material guidance, InventoryItem, logs, consumption and waste | Date-based planning; no sensor or microbial assessment |
| 3. Single-vendor branding | UC-01, UC-09/10, UC-26 | Storefront, Category, Product and MenuPhoto | One kitchen; no marketplace competitor feed |
| 4. Data-driven analytics | UC-18/19, UC-27/28 | Order, financial events, consumption and dated demand sources | Missing cost remains unknown; forecasts are estimates |
| 5. Menu recommendations | UC-02/03/04 | RecommendationSession and RecommendationEvent | Explainable ranking and bounded candidates; impact requires user evaluation |

## 3.10 CONCLUSION

The updated design connects each objective to an implemented workflow while separating future capacity, ingredient availability, payment evidence and actual fulfilment. It also recognises the owner’s workload: several eligible orders can share a progress confirmation, compatible cooking can be explicitly combined, and intermediate updates are optional. Chapter 4 explains how these responsibilities appear in the current interfaces and code.
