"""Rebuild the report's technical figures in a conventional, editable UML style.
Run beside diagram-source.json and structured_renderer.py. No production data access.
"""
from pathlib import Path
import json,re,heapq,math
from structured_renderer import Canvas,wrap,measure,simplify
ROOT=Path(__file__).resolve().parent
F=ROOT/'figures';F.mkdir(exist_ok=True)
SOURCES=json.loads((ROOT/'diagram-source.json').read_text())
SOURCE={v['args'][0]:v for v in SOURCES}
manifest=[]

def done(c):
 manifest.append(c.save(F,SOURCE[c.name]))
 return c

def route(c,src,dst,arrow='none',dashed=False,full='',cards=None,used=None):
 """Obstacle-aware orthogonal routing with a turn penalty and port separation."""
 grid=10;pad=14;nodes=cards or c.nodes;used=used if used is not None else {}
 blocked=set()
 for key,v in nodes.items():
  if v['shape'] not in ['rect','cylinder']:continue
  x,y,w,h=v['box']
  for i in range(math.floor((x-pad)/grid),math.ceil((x+w+pad)/grid)+1):
   for j in range(math.floor((y-pad)/grid),math.ceil((y+h+pad)/grid)+1):blocked.add((i,j))
 candidates={}
 for key in [src,dst]:
  x,y,w,h=nodes[key]['box'];out=[]
  for side in ['T','B','L','R']:
   for frac in [.5,.25,.75]:
    if side in ['T','B']:p=(round((x+w*frac)/grid)*grid,y if side=='T' else y+h);q=(round(p[0]/grid),round((p[1]+(-30 if side=='T' else 30))/grid))
    else:p=(x if side=='L' else x+w,round((y+h*frac)/grid)*grid);q=(round((p[0]+(-30 if side=='L' else 30))/grid),round(p[1]/grid))
    # Reject ports whose outward segment enters another card.
    if q in blocked:continue
    out.append((p,q,side))
  candidates[key]=out
 targets={q:(p,side) for p,q,side in candidates[dst]}
 frontier=[];dist={};prev={};origin={};serial=0
 for p,q,side in candidates[src]:
  k=(q[0],q[1],-1);cost=used.get(('port',p),0)*45;dist[k]=cost;origin[k]=(p,side);heapq.heappush(frontier,(cost,k))
 end=None
 while frontier:
  cost,k=heapq.heappop(frontier)
  if cost!=dist.get(k):continue
  x,y,di=k
  if (x,y) in targets:end=k;break
  for nd,(dx,dy) in enumerate([(1,0),(-1,0),(0,1),(0,-1)]):
   nx,ny=x+dx,y+dy
   if nx<3 or nx>int(c.w/grid)-3 or ny<3 or ny>int(c.h/grid)-3 or (nx,ny) in blocked:continue
   edge=tuple(sorted(((x,y),(nx,ny))));nc=cost+1+(1.8 if di not in [-1,nd] else 0)+used.get(edge,0)*7+used.get(('point',(nx,ny)),0)*.35
   nk=(nx,ny,nd)
   if nc<dist.get(nk,1e20):
    dist[nk]=nc;prev[nk]=k;origin[nk]=origin[k];heapq.heappush(frontier,(nc,nk))
 if end is None:raise RuntimeError((c.name,src,dst,'No orthogonal route'))
 seq=[];k=end
 while True:
  seq.append((k[0],k[1]))
  if k not in prev:break
  k=prev[k]
 seq.reverse();sp,ss=origin[end];tp,ts=targets[seq[-1]]
 for a,b in zip(seq,seq[1:]):used[tuple(sorted((a,b)))]=used.get(tuple(sorted((a,b))),0)+1
 for p in seq:used[('point',p)]=used.get(('point',p),0)+1
 used[('port',sp)]=used.get(('port',sp),0)+1;used[('port',tp)]=used.get(('port',tp),0)+1
 pts=simplify([sp]+[(x*grid,y*grid) for x,y in seq]+[tp])
 c.edge(pts,src,dst,arrow=arrow,dashed=dashed,full=full)
 return sp,ss,tp,ts,pts

def multiplicity(c,p,side,s):
 x,y=p
 if side=='T':c.text(x+10,y-29,s,size=21,anchor='start',background=True)
 elif side=='B':c.text(x+10,y+8,s,size=21,anchor='start',background=True)
 elif side=='L':c.text(x-11,y+7,s,size=21,anchor='end',background=True)
 else:c.text(x+11,y+7,s,size=21,anchor='start',background=True)

def usecase(customer=True):
 name='usecase-customer' if customer else 'usecase-owner';c=Canvas(name,1600,1300 if customer else 1460,SOURCE[name]['args'][-1])
 c.frame((240,55,1120,1150 if customer else 1165),'Dapur Kita · customer functions' if customer else 'Dapur Kita · owner functions')
 if customer:
  left=[('u1','UC-01\nBrowse menu and details'),('u2','UC-02\nReceive menu suggestions'),('u23','UC-23\nUse kitchen help / assistant'),('u3','UC-03\nManage basket'),('u4','UC-04\nPlace preorder'),('u7','UC-07\nMake payment')]
  right=[('u8','UC-08\nView own orders'),('u20','UC-20\nManage account / email choices'),('u21','UC-21\nAmend delivery / handover'),('u22','UC-22\nReview a delivered menu'),('u5','UC-05\nCheck dates and kitchen times'),('u6','UC-06\nChoose fulfilment / address')]
 else:
  left=[('a','UC-09/10\nManage menus / categories'),('b','UC-11/12\nManage ingredients'),('c','UC-13/14\nManage / receive batches'),('d','UC-15\nReview freshness / holds'),('e','UC-16\nManage orders'),('f','UC-17\nConfirm actual progress'),('g','UC-18/19\nView / filter sales and costs')]
  right=[('h','UC-24\nCalculate / confirm plans'),('i','UC-25\nReview cooking / closures'),('j','UC-26\nManage kitchen settings'),('k','UC-27\nInspect FreshCast scenarios'),('l','UC-28\nRecord payment / waste'),('m','UC-29\nRecord courier / contact'),('n','UC-30\nProcess email reminders')]
 for col,items in [(310,left),(930,right)]:
  for i,(key,label) in enumerate(items):c.node(key,(col,145+i*160,360,100),label,'ellipse',size=28)
 c.node('actorL1',(90,300,60,105),'Visitor /\ncustomer' if customer else 'Owner / staff','actor',size=25)
 c.node('actorL2',(90,810,60,105),'Customer' if customer else 'Owner / staff','actor',size=25)
 c.node('actorR1',(1450,310,60,105),'Customer' if customer else 'Owner / staff','actor',size=25)
 c.node('actorR2',(1450,880,60,105),'Payment\nprovider' if customer else 'Owner / staff','actor',size=25)
 # Association lines are straight and have no arrowheads (standard UML).
 for i,(key,label) in enumerate(left):
  actor='actorL1' if i<3 else 'actorL2';p=(150,350 if i<3 else 860)
  c.edge([p,c.anchor(key,'L')],actor,key,arrow='none',orthogonal=False)
 if customer:
  for key,_ in right[:4]:c.edge([(1450,360),c.anchor(key,'R')],'actorR1',key,arrow='none',orthogonal=False)
  c.edge([c.anchor('u7','B'),(490,1165),(1420,1165),(1420,930),(1450,930)],'u7','actorR2',arrow='none')
  c.edge([c.anchor('u4','R'),c.anchor('u5','L')],'u4','u5',arrow='open',dashed=True,label='«include»',label_at=(800,806),size=25)
  c.edge([c.anchor('u4','R',.78),(760,863),(760,995),(930,995)],'u4','u6',arrow='open',dashed=True,label='«include»',label_at=(840,961),size=25)
  c.edge([c.anchor('u2','R'),(715,355),(715,195),c.anchor('u1','R')],'u2','u1',arrow='open',dashed=True,label='«extend»',label_at=(790,260),size=25)
 else:
  for i,(key,_) in enumerate(right):
   actor='actorR1' if i<3 else 'actorR2';c.edge([(1450,360 if i<3 else 930),c.anchor(key,'R')],actor,key,arrow='none',orthogonal=False)
  c.edge([c.anchor('f','R'),(720,995),(720,835),c.anchor('e','R')],'f','e',arrow='open',dashed=True,label='«extend»',label_at=(795,905),size=25)
  c.node('scheduler',(870,1230,60,100),'Scheduler','actor',size=25);c.node('smtp',(1250,1230,60,100),'SMTP provider','actor',size=25)
  c.edge([(900,1230),(900,1175),(970,1175),(970,1155)],'scheduler','n',arrow='none')
  c.edge([(1280,1230),(1280,1175),(1250,1175),(1250,1155)],'smtp','n',arrow='none')
 c.text(800,c.h-45,'Repeated customer / owner symbols identify the same role; they are repeated to keep associations readable.',size=23,width=1450)
 return done(c)

def activity(name):
 c=Canvas(name,1080,1500,SOURCE[name]['args'][-1]);labels={s[0]:s[1] for s in SOURCE[name]['args'][1]}
 def n(k,x,y,w=430,h=86,label=None,shape='action'):
  c.node(k,(x,y,w,h),labels.get(k,'') if label is None else label,shape,size=27)
 def ini(x,y):n('s',x,y,28,28,shape='initial')
 def end(x,y):n('z',x,y,34,34,shape='final')
 def merge(k,x,y):n(k,x,y,30,30,'','merge')
 def e(a,b,via=None,label=None,at=None,sa='B',tb='T'):
  points=[c.anchor(a,sa)]+(via or [])+[c.anchor(b,tb)];routed=[points[0]]
  for p in points[1:]:
   q=routed[-1]
   if p[0]!=q[0] and p[1]!=q[1]:
    if abs(p[0]-q[0])<12:
     mid=(p[1]+q[1])/2;routed.extend([(q[0],mid),(p[0],mid)])
    else:routed.append((p[0],q[1]) if sa in ['L','R'] else (q[0],p[1]))
   routed.append(p)
  c.edge(routed,a,b,label=label,label_at=at,size=25)
 if name=='activity-checkout':
  c.h=1620;ini(366,28);n('a',165,95);merge('retry',365,220);n('b',165,285);n('c',165,420);n('d',250,550,260,130,shape='diamond')
  n('f',730,550,260,130,label='Request owner\nreview?',shape='diamond');n('g',680,755,350,100);n('j',680,920,350,110);n('r',680,1110,350,100,label='Adjust basket or time;\nshow clear recovery')
  merge('quote',365,755);n('e',165,880);n('h',165,1040,430,120);n('i',165,1250,430,105);end(363,1455)
  e('s','a');e('a','retry');e('retry','b');e('b','c');e('c','d');e('d','quote',label='[yes]',at=(430,709));e('d','f',sa='R',tb='L',label='[no]',at=(620,581))
  e('f','g',label='[yes]',at=(907,704));e('g','j');e('j','quote',sa='L',tb='R',via=[(635,975),(635,770)],label='[workable]',at=(641,834));e('f','r',sa='R',tb='R',via=[(1050,615),(1050,1160)],label='[no]',at=(1009,570));e('r','retry',sa='R',tb='R',via=[(1060,1160),(1060,235)])
  e('quote','e');e('e','h',label='[place]',at=(432,992));e('h','i');e('i','z')
 elif name=='activity-freshness':
  c.h=1570;ini(526,25);n('a',310,90,460,90);n('b',405,225,270,130,shape='diamond')
  n('c',35,425,300,105);n('d',390,425,300,105);n('e',745,425,300,105,label='Receipt date + documented\nstorage-life days')
  merge('evidence',525,620);n('f',310,710,460,100);n('g',310,865,460,95);n('h',405,1000,270,140,label='Handling uncertain\nor breached?',shape='diamond');n('i',790,1010,250,110,label='Hold batch; exclude\nfrom allocation');merge('save',525,1195);n('j',310,1280,460,85);n('k',310,1410,460,95,label='Show date-based status,\nremaining window and holds');end(523,1530)
  e('s','a');e('a','b');e('b','d',label='[manufacture]',at=(640,380));e('b','c',sa='L',via=[(185,290)],label='[printed]',at=(280,261));e('b','e',sa='R',via=[(895,290)],label='[receipt]',at=(800,261));e('c','evidence',via=[(185,635)],tb='L');e('d','evidence');e('e','evidence',via=[(895,635)],tb='R');e('evidence','f');e('f','g');e('g','h');e('h','i',sa='R',tb='L',label='[yes]',at=(735,1036));e('h','save',label='[no]',at=(597,1155));e('i','save',via=[(915,1210)],tb='R');e('save','j');e('j','k');e('k','z')
 elif name=='activity-planner':
  c.h=1530;ini(371,25);merge('retry',370,95);n('a',170,175);n('b',170,315);n('c',170,455,430,115);n('d',255,610,260,125,shape='diamond');n('e',170,805,430,95);n('g',170,965);n('h',255,1100,260,130,label='Locked state\nstill matches?',shape='diamond');n('i',170,1320,430,110);end(368,1480);n('f',730,620,300,120,label='Adjust time / quantity,\nor review a reasoned\nmanual arrangement');n('r',730,1105,300,110)
  e('s','retry');e('retry','a');e('a','b');e('b','c');e('c','d');e('d','e',label='[yes]',at=(437,760));e('d','f',sa='R',tb='L',via=[(640,672.5),(640,680)],label='[no]',at=(620,640));e('f','retry',sa='R',tb='R',via=[(1050,680),(1050,110)])
  e('e','g');e('g','h');e('h','i',label='[matches]',at=(462,1263));e('h','r',sa='R',tb='L',via=[(640,1165),(640,1160)],label='[changed]',at=(628,1127));e('r','retry',sa='R',tb='L',via=[(1060,1160),(1060,140),(80,140),(80,110)]);e('i','z')
 elif name=='activity-fulfilment':
  c.h=1550;ini(526,25);merge('retry',525,95);n('a',310,170,460,85);n('b',310,310,460,95);n('c',310,460,460,100);n('d',390,600,300,150,label='All orders valid\nand stock sufficient?',shape='diamond');n('r',795,615,250,115,label='Roll back group;\nidentify order\nfor review');n('e',310,820,460,100);n('f',415,965,250,130,shape='diamond');n('g',25,1135,420,110,label='Book rider; record reference;\nconfirm actual handover');n('h',700,1135,350,100);n('i',25,1300,420,85);merge('handover',525,1330);n('j',600,1405,450,80);end(808,1510)
  e('s','retry');e('retry','a');e('a','b');e('b','c');e('c','d');e('d','r',sa='R',tb='L',via=[(740,675),(740,672.5)],label='[no]',at=(740,635));e('r','retry',sa='R',tb='R',via=[(1060,672.5),(1060,110)]);e('d','e',label='[yes]',at=(595,777));e('e','f');e('f','g',sa='L',via=[(235,1030)],label='[delivery]',at=(290,998));e('f','h',sa='R',via=[(875,1030)],label='[collection]',at=(799,997));e('g','i');e('i','handover',sa='R',tb='L',via=[(490,1342.5),(490,1345)]);e('h','handover',via=[(875,1345)],tb='R');e('handover','j',via=[(540,1445)],tb='L');e('j','z')
 return done(c)

def classes():
 name='class-domain';c=Canvas(name,1640,1120,SOURCE[name]['args'][-1]);body=SOURCE[name]['args'][1]
 data={}
 for m in re.finditer(r'(\w+)\[label="\{([^\"]+)\}"\];',body):
  groups=m[2].split('|');title=groups[0];fields=[v.strip() for v in groups[1].split('\\l') if v.strip()] if len(groups)>1 else [];methods=[v.strip() for v in groups[2].split('\\l') if v.strip()] if len(groups)>2 else []
  if title.startswith('«service'):methods=fields;fields=[];title=title.replace('» ','»\n')
  data[m[1]]=(title,fields,methods)
 positions={'Product':(70,60),'Recipe':(460,60),'RawMaterial':(850,60),'Inventory':(1240,60),'Order':(70,470),'OrderItem':(460,470),'OI':(850,470),'S':(70,875),'P':(1240,835)}
 for key,(x,y) in positions.items():c.card(key,x,y,330,*data[key],size=24)
 used={}
 links=[('Product','Recipe','1','0..*'),('RawMaterial','Recipe','1','0..*'),('Order','OrderItem','1','0..*'),('Product','OrderItem','0..1','0..*'),('OrderItem','OI','1','0..*'),('RawMaterial','OI','1','0..*'),('RawMaterial','Inventory','1','0..*')]
 for a,b,ac,bc in links:
  sp,ss,tp,ts,_=route(c,a,b,full=f'{a} {ac} — {bc} {b}',used=used);multiplicity(c,sp,ss,ac);multiplicity(c,tp,ts,bc)
 for a,b,label in [('S','Product','reads accepted settings'),('S','Order','plans around bookings'),('P','Order','validates progress'),('P','Inventory','transactional FEFO')]:route(c,a,b,arrow='open',dashed=True,full=label,used=used)
 c.text(820,1080,'Solid lines: model associations with multiplicities. Dashed arrows: service dependencies (not database tables).',size=25,width=1500)
 return done(c)

ERD_GRIDS={
 'erd-commerce':[['Category','Product','CartItem'],['User','Order','OrderItem'],['Address',None,None]],
 'erd-inventory':[['Product','ProductIngredient','RawMaterial'],['OrderItem','OrderIngredient','InventoryItem'],['IngredientConsumption','InventoryLog','WasteRecord']],
 'erd-operations':[['User','PaymentEvent','Order','OrderReminder'],['Wallet','WalletTransaction','OrderAmendment',None],['Storefront','KitchenBlock','OperatingExpense',None]],
 'erd-engagement':[['User','Review','Product'],['Order','RecommendationEvent','RecommendationSession'],['MenuPhoto','AuthAttempt',None]]}

def erd(name):
 args=SOURCE[name]['args'];nodes,links=args[1:3];grid=ERD_GRIDS[name];cols=len(grid[0]);cardw=360 if cols==3 else 330;gap=105;width=cols*(cardw+gap)+90;c=Canvas(name,width,1700,args[3]);y=70
 for row in grid:
  hs=[]
  for col,key in enumerate(row):
   if key is None:continue
   fields=nodes[key]
   hs.append(c.card(key,70+col*(cardw+gap),y,cardw,key,fields,size=25))
  y+=max(hs)+125
 c.h=y+135;used={}
 for a,b,ac,label in links:
  sp,ss,tp,ts,_=route(c,a,b,full=f'{a} {ac} — 0..* {b}: {label}',used=used);multiplicity(c,sp,ss,ac);multiplicity(c,tp,ts,'0..*')
 if name=='erd-operations':
  sp,ss,tp,ts,_=route(c,'User','Wallet',full='User 1 — 0..1 Wallet',used=used);multiplicity(c,sp,ss,'1');multiplicity(c,tp,ts,'0..1')
  x,y1,w,h=c.nodes['PaymentEvent']['box'];p1=(x+w,y1+h*.32);p2=(x+w,y1+h*.68);c.edge([p1,(x+w+70,p1[1]),(x+w+70,p2[1]),p2],'PaymentEvent','PaymentEvent',arrow='none',full='resolves: 0..1 — 0..1');multiplicity(c,p1,'R','0..1');multiplicity(c,p2,'R','0..1')
 if name=='erd-engagement':
  sp,ss,tp,ts,_=route(c,'Order','RecommendationEvent',full='Order 0..1 — 0..1 RecommendationEvent: attributed order',used=used);multiplicity(c,sp,ss,'0..1');multiplicity(c,tp,ts,'0..1')
 note=args[4] if len(args)>4 else 'PK = primary key; FK = foreign key. Selected fields are shown; the full dictionary appears in Appendix D.'
 c.text(width/2,c.h-120,note,size=24,width=width-140)
 return done(c)

def architecture():
 name='architecture';c=Canvas(name,1500,1110,SOURCE[name]['args'][-1]);labels={s[0]:s[1] for s in SOURCE[name]['args'][1]}
 pos={'customer':(60,65,390,130),'owner':(555,65,390,130),'cron':(1050,65,390,130),'api':(525,340,450,125),'services':(525,595,450,125),'db':(60,900,390,160),'model':(555,900,390,160),'provider':(1050,900,390,160)}
 for key,p in pos.items():c.node(key,p,labels[key],shape='cylinder' if key=='db' else 'rect',size=28)
 c.edge([c.anchor('customer','B'),(255,402.5),c.anchor('api','L')],'customer','api',label='HTTPS JSON',label_at=(340,364),size=26)
 c.edge([c.anchor('owner','B'),c.anchor('api','T')],'owner','api',label='HTTPS JSON',label_at=(850,255),size=26)
 c.edge([c.anchor('cron','B'),(1245,402.5),c.anchor('api','R')],'cron','api',label='Authenticated call',label_at=(1210,349),size=26)
 c.edge([c.anchor('api','B'),c.anchor('services','T')],'api','services')
 c.edge([c.anchor('services','B',.15),(592.5,800),(255,800),c.anchor('db','T')],'services','db',label='ORM transactions',label_at=(345,755),size=26)
 c.edge([c.anchor('services','B'),c.anchor('model','T')],'services','model',label='Read-only model',label_at=(850,830),size=26)
 c.edge([c.anchor('services','B',.85),(907.5,800),(1245,800),c.anchor('provider','T')],'services','provider',label='Verification / email',label_at=(1195,755),size=26)
 return done(c)

# Short labels keep message text above its arrow, within the participant columns.
COMPACT={
 'sequence-discovery':['Open menu / finder','Request menu suggestions','Read menus, history and basket','Candidate / preference evidence','Rank, price baskets; check slots','Save suggestion session','Alternatives, totals and reasons','Record impression / interaction'],
 'sequence-basket':['Add item / edit quantity','POST / PATCH with CSRF','Validate owner and quantity; save','Saved basket row','Mutation confirmed','Refresh basket','Authoritative rows and quantities','Show quantity and timed popup'],
 'sequence-checkout':['Choose time and payment','Request quote + basket version','Read settings, recipes, bookings','Quote / plan or review request','Place order + checkout UUID','Lock records; recheck availability','Save order and accepted snapshots','Clear basket; retain unique UUID','Return saved order (retry-safe)'],
 'sequence-paypal':['Open order payment','Create order-bound checkout','Send server amount and identity','Provider order identifier','Buyer approves Sandbox payment','Capture / recheck provider order','Verify status, amount, currency','Verified provider evidence','Lock; record event; mark paid','Verified payment result'],
 'sequence-replan':['Calculate agreed future time','Preview accepted / current settings','Read recipes, hours and bookings','Schedule backward across allowed days','Tasks, warnings and signed preview','Review and confirm','Confirm signed proposal','Lock; recompute; verify version','Save plan and amendment','Saved plan / stale-state recovery'],
 'sequence-fefo':['Confirm eligible food-ready orders','Lock orders; validate preparation','Deduct accepted recipe once','Lock stock in stable FEFO order','Consume lots; save cost and audit','Set deducted flag; mark cooked','Progress saved; payment unchanged'],
 'sequence-inventory':['Choose storage / evidence mode','Copy matching guidance (optional)','Save batch + record version','Validate limits; enforce hold','Lock version; save batch and audit','Stock and date-based status'],
 'sequence-analytics':['Choose report / date range','Request recorded sales / costs','Aggregate orders and consumption','Recorded revenue / cost evidence','Calculate known contribution','Charts, exclusions and export scope'],
 'sequence-freshcast':['Choose forecast data source','Request source-specific plan','Read database OR model archive','Labelled demand, recipes and lots','Separate bookings; allocate stock','Need, unused stock and limitations','Compare hypothetical action','Request scenario; same baseline','Comparison; no stock write'],
 'sequence-reminders':['Authenticated worker call','Validate secret / mail readiness','Read due events and receipts','Lock; recheck consent and time','Send eligible email','Provider accepted / failed','Save receipt after acceptance','Authenticated run totals'],
 'sequence-escrow':['Create own order / wallet invoice','Reference, chain, amount, deadline','Sign and broadcast funding','Save hash; request verification','Read receipt, block and contract','Confirmed / pending / unavailable','Verify exact invoice; save once','Paid / pending / rejected']}

def sequence(name):
 args=SOURCE[name]['args'];actors,events=args[1:3];c=Canvas(name,1140,1400,args[3]);xs=[125,420,715,1010];y=190;frames=[];num=0;lifelines=[]
 # All lifelines are exported as separate editable dashed connectors.
 for i,a in enumerate(actors):c.node('p'+str(i),(xs[i]-111,35,222,92),a,'rect',size=27,bold=True)
 for ev in events:
  if ev[0]=='frame':
   label='loop [at most 3 email attempts]' if 'bounded' in ev[1] else 'critical [atomic database transaction]'
   frames.append((y-20,label));y+=55
  elif ev[0]=='end':
   sy,label=frames.pop();c.frame((12,sy,1116,y-sy+10));c.text(30,sy+9,label,size=24,anchor='start',background=True);y+=40
  elif ev[0]=='note':
   note=ev[1];lines=wrap(note,1020,24);h=len(lines)*28.32+25;x=40
   c.node('note'+str(num),(x,y,1060,h),'','note');c.text(570,y+12,note,size=24,width=1020);y+=h+30
  else:
   a,b,full,*reply=ev;ai=actors.index(a);bi=actors.index(b);num+=1;label=f'{num}. '+COMPACT[name][num-1];x1,x2=xs[ai],xs[bi]
   if ai==bi:
    # Place loop label across available space without touching the next lifeline.
    side=1 if ai<3 else -1;ww=250;xx=x1+25 if side==1 else x1-25
    lines=wrap(label,ww,25);yy=y+len(lines)*29.5+8
    c.text(xx,y,label,size=25,width=ww,anchor='start' if side==1 else 'end',background=True)
    c.edge([(x1,yy),(x1+side*85,yy),(x1+side*85,yy+28),(x1,yy+28)],arrow='open' if reply else 'filled',dashed=bool(reply),full=full);y=yy+68
   else:
    ww=abs(x2-x1)-24;lines=wrap(label,ww,25);yy=y+len(lines)*29.5+7
    c.text((x1+x2)/2,y,label,size=25,width=ww,background=True)
    c.edge([(x1,yy),(x2,yy)],arrow='open' if reply else 'filled',dashed=bool(reply),full=full)
    # A short execution specification shows the receiver is active on receipt.
    c.node('activation'+str(num),(x2-5,yy,10,23),'','rect',fill='#eeeeee');y=yy+47
 assert num==len(COMPACT[name]),(name,num)
 c.h=y+55
 for i,x in enumerate(xs):
  # Lifelines must sit behind messages and activation bars.
  saved=c.wires;c.wires=[];c.edge([(x,127),(x,c.h-20)],arrow='none',dashed=True,full='Lifeline: '+actors[i]);line=c.wires;c.wires=line+saved
 return done(c)

if __name__=='__main__':
 import sys
 only=set(sys.argv[1:])
 for s in SOURCES:
  name=s['args'][0]
  if only and name not in only:continue
  if name.startswith('usecase'):usecase(name.endswith('customer'))
  elif name.startswith('activity'):activity(name)
  elif name.startswith('class'):classes()
  elif name.startswith('erd'):erd(name)
  elif name=='architecture':architecture()
  else:sequence(name)
 (F/'diagram-manifest.json').write_text(json.dumps(manifest,indent=2))
 print('Redrawn',len(manifest),'editable technical diagrams')
