from pathlib import Path
import subprocess,html,textwrap,json
import fitz
import functools
json.dumps=functools.partial(json.dumps,ensure_ascii=False)
F=Path(__file__).resolve().parent/'figures';F.mkdir(exist_ok=True)
manifest=[]
def dot(name,body,title):
 if name.startswith(('erd-','class-')):
  import re
  keys=re.findall(r'^([A-Za-z][A-Za-z0-9_]*)\s*\[label=',body,re.M)
  def html_record(match):
   key,value=match.group(1),match.group(2)[1:-1]
   value=re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m.group(1),16)),value)
   value=value.replace('\\\\l','\\l')
   groups=value.split('|');rows=[]
   for index,group in enumerate(groups):
    entries=[v.strip() for v in group.replace('; ','\\l').split('\\l') if v.strip()]
    content='<BR ALIGN="LEFT"/>'.join(html.escape(v) for v in entries)
    if index==0:content='<B>'+content+'</B>'
    rows.append('<TR><TD ALIGN="LEFT" BALIGN="LEFT" CELLPADDING="7">'+content+'</TD></TR>')
   return key+'[shape=plain,label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">'+''.join(rows)+'</TABLE>>];'
  body=re.sub(r'(\w+)\s*\[label="(\{[^"\n]+\})"\];',html_record,body)

  body='edge[constraint=false];\n'+body
  for start in range(0,len(keys),3):
   group=keys[start:start+3];body+='\n{rank=same;'+ ';'.join(group)+';}'
   for a,b in zip(group,group[1:]):body+=f'\n{a}->{b}[style=invis,weight=100];'
  for a,b in zip(keys,keys[3:]):body+=f'\n{a}->{b}[style=invis,constraint=true,weight=80];'
 src='digraph G { graph [rankdir=TB, bgcolor="white", pad="0.15", nodesep=0.32, ranksep=0.48, fontname="DejaVu Sans", fontsize=14]; node [shape=box, style="rounded,filled", fillcolor="white", color="#273343", penwidth=1.25, fontname="DejaVu Sans", fontsize=13, margin="0.14,0.10"]; edge [color="#273343", fontname="DejaVu Sans", fontsize=11, arrowsize=.7];\n'+body+'\n}'
 (F/(name+'.dot')).write_text(src)
 for ext in ['svg','png']:
  subprocess.run(['dot','-T'+ext,'-Gdpi=200',str(F/(name+'.dot')),'-o',str(F/(name+'.'+ext))],check=True)
 manifest.append(dict(file=name,title=title,type='Graphviz / editable DOT'))
def flow(name,steps,edges,title):
 b=[]
 for key,label,shape in steps:
  b.append(f'{key} [label={json.dumps(label)},shape={shape}'+(',style=filled,fillcolor="#273343",fontcolor="white"' if shape=='circle' else '')+'];')
 for a,c,label in edges:b.append(f'{a} -> {c} [label={json.dumps(label)}];')
 dot(name,'\n'.join(b),title)
# Actor boundary diagrams, split by role to retain legible text at A4.
dot('usecase-customer','''rankdir=LR;
visitor [shape=plaintext,label="«actor»\nVisitor"];
customer [shape=plaintext,label="«actor»\nCustomer"];
provider [shape=plaintext,label="«external system»\nPayment provider"];
subgraph cluster_app {label="Dapur Kita — customer boundary";color="#8894a3";fontsize=16;
node [shape=ellipse];
u1[label="UC-01 Browse menu\nand product details"];u2[label="UC-02 Receive menu\nsuggestions"];
u3[label="UC-03 Manage basket"];u4[label="UC-04 Place preorder"];
u5[label="UC-05 Check dates\nand kitchen times"];u6[label="UC-06 Choose fulfilment\nand address"];
u7[label="UC-07 Make payment"];u8[label="UC-08 View own orders"];
u20[label="UC-20 Manage account\nand email preferences"];u21[label="UC-21 Amend delivery\nor handover details"];
u22[label="UC-22 Review a\ndelivered menu"];u23[label="UC-23 Use kitchen help\nand order assistant"];
}
visitor -> u1 [dir=none];visitor -> u2 [dir=none];visitor -> u23 [dir=none];
customer -> u3 [dir=none];customer -> u4 [dir=none];customer -> u7 [dir=none];customer -> u8 [dir=none];customer -> u20 [dir=none];customer -> u21 [dir=none];customer -> u22 [dir=none];
u4 -> u5 [style=dashed,label="«include»"];u4 -> u6 [style=dashed,label="«include»"];
u7 -> provider [dir=none];
u2 -> u1 [style=dashed,label="«extend»"];''','Customer use cases')
dot('usecase-owner','''rankdir=LR;
owner[shape=plaintext,label="«actor»\nKitchen owner / staff"];
scheduler[shape=plaintext,label="«external system»\nAuthenticated scheduler"];
email[shape=plaintext,label="«external system»\nSMTP provider"];
subgraph cluster_app{label="Dapur Kita — owner boundary";color="#8894a3";fontsize=16;node[shape=ellipse];
a[label="UC-09/10 Manage /\ncreate menus and categories"];b[label="UC-11/12 Manage /\ncreate ingredients"];
c[label="UC-13/14 Manage /\nreceive inventory batches"];d[label="UC-15 Review date-based\nfreshness and holds"];
e[label="UC-16 Manage orders"];f[label="UC-17 Confirm actual\nprogress (single / grouped)"];
g[label="UC-18/19 View and filter\nsales / cost reports"];h[label="UC-24 Calculate / confirm\npreparation or replan"];
i[label="UC-25 Review shared cooking\nand kitchen closures"];j[label="UC-26 Manage storefront\nand fulfilment settings"];
k[label="UC-27 Inspect FreshCast\nforecasts and scenarios"];l[label="UC-28 Record payments,\nrefund evidence and waste"];
m[label="UC-29 Record courier\nreference / contact"];n[label="UC-30 Process opted-in\nand owner reminders"];
}
owner -> {a b c d e f g h i j k l m} [dir=none];
e -> f[style=dashed,label="«extend»",dir=back];
scheduler -> n[dir=none];n -> email[dir=none];owner -> n[dir=none];''','Owner and integration use cases')
flow('activity-checkout',[
('s','', 'circle'),('a','Browse, choose items and edit basket','box'),('b','Checkout: choose delivery / collection,\ncontact details and a future time','box'),('c','Server validates menu sale rules,\ncutoff, daily cap and recipe resources','box'),('d','Automatic plan fits?','diamond'),('e','Review confirmed quote and\nexplicit payment choice','box'),('f','Customer requests owner review?','diamond'),('g','Save unpaid request;\nno tasks or payment reserved','box'),('h','Lock and recompute; save order,\naccepted snapshots and task plan once','box'),('i','Provider / owner verifies payment\nin a separate workflow','box'),('j','Owner confirms or agrees a later\ntime and preparation plan','box'),('r','Show clear recovery; adjust basket / time','box'),('z','', 'doublecircle')],
[('s','a',''),('a','b',''),('b','c',''),('c','d',''),('d','e','yes'),('d','f','no'),('f','g','yes, eligible request'),('f','r','no'),('r','b',''),('e','h','place'),('h','i',''),('g','j',''),('j','e','workable plan'),('i','z','')], 'Preorder activity with confirmed and review paths')
flow('activity-freshness',[
('s','','circle'),('a','Choose ingredient, quantity, actual storage\nand receipt date','box'),('b','Expiry evidence mode','diamond'),('c','Enter printed use-by / best-before date','box'),('d','Enter manufacture date +\ndocumented shelf-life days','box'),('e','Enter receipt date + documented\nstorage-life days (custom or copied guide)','box'),('f','Review source conditions and any\nopened / thawed date-duration pair','box'),('g','Effective deadline = earliest\napplicable recorded limit','box'),('h','Handling uncertain / breached?','diamond'),('i','Hold batch and exclude from allocation','box'),('j','Validate and save batch with audit record','box'),('k','Compare deadline with Malaysia date;\nshow dated status, remaining window and holds','box'),('z','','doublecircle')],
[('s','a',''),('a','b',''),('b','c','label'),('b','d','manufacture'),('b','e','receipt'),('c','f',''),('d','f',''),('e','f',''),('f','g',''),('g','h',''),('h','i','yes'),('h','j','no'),('i','j',''),('j','k',''),('k','z','')], 'Inventory evidence and freshness activity')
flow('activity-planner',[
('s','','circle'),('a','Read accepted recipe and fulfilment terms;\nchoose future delivery / collection','box'),('b','Calculate steps backward from handover\nminus accepted travel buffer','box'),('c','Fit one worker, equipment, closures,\nhours, step waits and allowed multi-day span','box'),('d','Feasible plan?','diamond'),('e','Review calculated start, finish,\nper-day work and warnings','box'),('f','Choose another time / quantity,\nor review a reasoned manual arrangement','box'),('g','Confirm signed, short-lived preview','box'),('h','Recheck locked current state','diamond'),('i','Save plan and amendment;\nreserve time, leave ingredient stock unchanged','box'),('r','Reject stale preview; recalculate','box'),('z','','doublecircle')],
[('s','a',''),('a','b',''),('b','c',''),('c','d',''),('d','e','yes'),('d','f','no'),('f','a',''),('e','g',''),('g','h',''),('h','i','matches'),('h','r','changed'),('r','a',''),('i','z','')], 'Owner preparation planning activity')
flow('activity-fulfilment',[
('s','','circle'),('a','Read daily preparation / handover queue','box'),('b','Select up to 20 eligible orders\nand confirm food actually ready','box'),('c','Lock orders and stock; validate every\nversion and accepted ingredient requirement','box'),('d','Every selected order valid\nand stock sufficient?','diamond'),('e','FEFO deduction + consumption + audit;\nmark cooked exactly once per order','box'),('r','Roll back group; show order needing review','box'),('f','Delivery or collection?','diamond'),('g','Book rider outside website; record reference;\nconfirm actual handover (dispatch optional)','box'),('h','Confirm actual customer collection','box'),('i','Confirm actual delivery, not a clock estimate','box'),('j','Keep payment / refund records separate','box'),('z','','doublecircle')],
[('s','a',''),('a','b',''),('b','c',''),('c','d',''),('d','e','yes'),('d','r','no'),('r','a',''),('e','f',''),('f','g','delivery'),('f','h','collection'),('g','i',''),('h','j',''),('i','j',''),('j','z','')], 'Actual progress and grouped fulfilment activity')
# UML class diagram: domain/data classes and service responsibilities; services are not tables.
dot('class-domain','''rankdir=TB;node[shape=record,style=filled,fillcolor="white"];
Product[label="{Product|name; price; selling_status\\lpreparation_tasks; batch_size; daily_capacity\\lselling_details; lead_hours; max_preparation_days\\l|+ get_available_quantity()\\l}"];
RawMaterial[label="{RawMaterial|name; unit; estimated_unit_cost\\lstorage_guidance\\l}"];
Recipe[label="{ProductIngredient|quantity_required\\l}"];
Order[label="{Order|status; payment_status; inventory_deducted\\ldelivery_at; preparation_at; preparation_end_at\\lpreparation_plan; fulfilment_snapshot\\lcheckout_request_id\\l}"];
OrderItem[label="{OrderItem|product_name; unit_price; quantity; subtotal\\lpreparation_snapshot; packaging_unit_cost\\l}"];
OI[label="{OrderIngredient|material_name; unit; quantity_per_portion\\l}"];
Inventory[label="{InventoryItem|quantity; received_date; expiry_date\\lexpiry_basis; storage_type; quarantined\\l}"];
S[label="{«service module» scheduling|+ schedule_order()\\l+ preparation_work()\\l+ automatic_plan()\\l}"];
P[label="{«service module» order_progress|+ validate_progress()\\l+ apply_progress()\\l}"];
Product -> Recipe[dir=none,taillabel="1",headlabel="0..*"];RawMaterial -> Recipe[dir=none,taillabel="1",headlabel="0..*"];
Order -> OrderItem[dir=none,taillabel="1",headlabel="0..*"];Product -> OrderItem[dir=none,taillabel="0..1",headlabel="0..*"];
OrderItem -> OI[dir=none,taillabel="1",headlabel="0..*"];RawMaterial -> OI[dir=none,taillabel="1",headlabel="0..*"];
RawMaterial -> Inventory[dir=none,taillabel="1",headlabel="0..*"];
S -> Product[style=dashed,label="reads accepted settings"];S -> Order[style=dashed,label="plans around bookings"];
P -> Order[style=dashed,label="validates progress"];P -> Inventory[style=dashed,label="transactional FEFO"];
''','Domain class and service responsibility diagram')
# ERD views: explicit cardinality label per relational link.
def erd(name,nodes,links,title,notes=''):
 b=['rankdir=TB;node[shape=record,style=filled,fillcolor="white"];']
 for key,fields in nodes.items():b.append(key+' [label='+json.dumps('{'+key+'|'+r'\l'.join(fields)+r'\l}')+'];')
 for parent,child,card,label in links:b.append(f'{parent} -> {child} [dir=none,taillabel="{card}",headlabel="0..*",label={json.dumps(label)},labeldistance=1.8];')
 if name=='erd-operations':
  b.append('User -> Wallet [dir=none,taillabel="1",headlabel="0..1",label="one-to-one"];')
  b.append('PaymentEvent -> PaymentEvent [dir=none,taillabel="0..1",headlabel="0..1",label="resolves"];')
 if name=='erd-engagement':b.append('Order -> RecommendationEvent [dir=none,taillabel="0..1",headlabel="0..1",label="attributed order"];')
 if notes:b.append('note[shape=note,fontsize=11,label='+json.dumps(notes)+'];')
 dot(name,'\n'.join(b),title)
erd('erd-commerce',{
'User':['PK id','username; email; is_staff'], 'Category':['PK id','name UNIQUE'],
'Product':['PK id','FK category_id NULL','name; price; selling_status','image_url; selling_details'],
'CartItem':['PK id','FK user_id; product_id','quantity'], 'Address':['PK id','FK user_id','recipient_name; address; phone'],
'Order':['PK id','FK user_id','FK address_id NULL','checkout_request_id UNIQUE','delivery_address JSON','status; total_amount; shipping_fee'],
'OrderItem':['PK id','FK order_id','FK product_id NULL','product_name; unit_price','quantity; preparation_snapshot']},
[('User','CartItem','1','owns'),('Product','CartItem','1','basket line'),('Category','Product','0..1','SET NULL'),('User','Address','1','saved address'),('User','Order','1','PROTECT'),('Address','Order','0..1','SET NULL'),('Order','OrderItem','1','contains'),('Product','OrderItem','0..1','SET NULL')], 'Commerce ERD', 'delivery_address preserves accepted address.\nJSON snapshots are columns, not separate entities.')
erd('erd-inventory',{
'Product':['PK id','name'], 'RawMaterial':['PK id','name; unit','storage_guidance JSON'],
'ProductIngredient':['PK id','FK product_id; raw_material_id','quantity_required'],
'InventoryItem':['PK id','FK raw_material_id','quantity; batch_code','received_date; expiry_date','storage_type; quarantined; unit_cost'],
'OrderItem':['PK id','FK order_id','quantity'], 'OrderIngredient':['PK id','FK order_item_id; raw_material_id','material_name; unit','quantity_per_portion'],
'IngredientConsumption':['PK id','FK order_item_id; inventory_item_id','quantity; unit_cost','recorded_expiry; batch_code'],
'InventoryLog':['PK id','FK inventory_item_id NULL','FK admin_id NULL','change; reason; reference'],
'WasteRecord':['PK id; request_id UNIQUE','FK inventory_item_id','quantity; estimated_cost; reason']},
[('Product','ProductIngredient','1','recipe'),('RawMaterial','ProductIngredient','1','recipe material'),('RawMaterial','InventoryItem','1','PROTECT'),('OrderItem','OrderIngredient','1','accepted recipe'),('RawMaterial','OrderIngredient','1','PROTECT'),('OrderItem','IngredientConsumption','1','PROTECT'),('InventoryItem','IngredientConsumption','1','PROTECT'),('InventoryItem','InventoryLog','0..1','SET NULL'),('InventoryItem','WasteRecord','1','PROTECT')], 'Recipes, batches and consumption ERD')
erd('erd-operations',{
'User':['PK id'], 'Order':['PK id','preparation_plan JSON','fulfilment_snapshot JSON','payment_instructions JSON'],
'PaymentEvent':['PK id; request_id UNIQUE','FK order_id; actor_id NULL','FK resolves_id NULL UNIQUE','kind; outcome; amount; source'],
'OrderAmendment':['PK id','FK order_id; actor_id NULL','before JSON; after JSON'],
'OrderReminder':['PK id','FK order_id','event; sent_at','UNIQUE(order_id,event)'],
'Wallet':['PK id','FK user_id UNIQUE','balance; wallet_address UNIQUE'],
'WalletTransaction':['PK id','FK wallet_id','amount; type; reference'],
'Storefront':['PK id (application uses 1)','branding; kitchen hours','fulfilment hours; fees; settings'],
'KitchenBlock':['PK id','start_at; end_at; reason'],
'OperatingExpense':['PK id; request_id UNIQUE','date; category; amount; voided']},
[('Order','PaymentEvent','1','PROTECT'),('User','PaymentEvent','0..1','actor SET NULL'),('Order','OrderAmendment','1','PROTECT'),('User','OrderAmendment','0..1','actor SET NULL'),('Order','OrderReminder','1','event receipt'),('Wallet','WalletTransaction','1','CASCADE')], 'Operations and payment ERD', 'User 1 — 0..1 Wallet (one-to-one).\nPaymentEvent resolves 0..1 earlier PaymentEvent (self one-to-one).\nStorefront, KitchenBlock and OperatingExpense have no Order FK.')
erd('erd-engagement',{
'User':['PK id'], 'Product':['PK id','image_url string'], 'Order':['PK id'],
'Review':['PK id','FK product_id; user_id','rating; comment','UNIQUE(user_id, product_id)'],
'RecommendationSession':['PK UUID id','owner_key; variant','context JSON; products JSON'],
'RecommendationEvent':['PK id; request_id UNIQUE','FK session_id','FK product_id NULL','FK order_id NULL UNIQUE','event; created_at'],
'MenuPhoto':['PK digest (SHA-256)','content (binary WebP)','width; height; created_at'],
'AuthAttempt':['PK id','key (hashed); created_at']},
[('User','Review','1','review author'),('Product','Review','1','reviewed menu'),('RecommendationSession','RecommendationEvent','1','CASCADE'),('Product','RecommendationEvent','0..1','SET NULL')], 'Engagement, photo and authentication ERD', 'Order 0..1 — 0..1 RecommendationEvent (one-to-one).\nProduct.image_url may reference MenuPhoto URL: no database FK.\nRecommendationSession.owner_key is hashed: no User FK.')
# Architecture
flow('architecture',[
('customer','Customer browser\nReact storefront / basket / checkout / orders','box'),('owner','Owner browser\nAdmin, Planner, Inventory, Sales, FreshCast','box'),('api','Django + DRF\nsession / CSRF / permissions / validation','box'),('services','Domain services\nscheduling; FEFO; recommendations; forecasts','box'),('db','PostgreSQL (Supabase)\norders, accepted snapshots, batch stock, photos, ledgers','cylinder'),('model','Versioned Genpact archive\nCatBoost model + source CSV + simulated operations','folder'),('provider','External services\nPayPal Sandbox / Sepolia RPC / SMTP\noptional bounded AI classification','box'),('cron','One authenticated reminder scheduler\nGitHub Actions → bounded worker','box')],
[('customer','api','HTTPS JSON'),('owner','api','HTTPS JSON'),('api','services',''),('services','db','ORM transactions'),('services','model','optional read-only'),('services','provider','server-side verification / mail'),('cron','api','Bearer-authenticated call')], 'Implemented application architecture')
# Sequence SVG: actor/object lifelines, alt frames and reply arrows.
def sequence(name,actors,events,title):
 w=820;xs=[90+i*(w-180)/(len(actors)-1) for i in range(len(actors))];y=112;parts=[];frames=[]
 def text(x,yy,t,size=19,anchor='middle',weight='normal',chars=31):
  wrapped=textwrap.wrap(t,chars) or ['']
  for i,s in enumerate(wrapped):parts.append(f'<text x="{x}" y="{yy+i*23}" text-anchor="{anchor}" font-family="DejaVu Sans" font-size="{size}" font-weight="{weight}" fill="#172334">{html.escape(s)}</text>')
 for i,a in enumerate(actors):
  parts.append(f'<rect x="{xs[i]-78}" y="10" width="156" height="70" rx="4" fill="#f2f4f6" stroke="#273343"/>')
  for j,t in enumerate(a.split('\n')):text(xs[i],37+j*24,t,18)
 for event in events:
  if event[0]=='frame':
   if frames:raise ValueError('nested not supported')
   frames.append((y,event[1]));y+=38
  elif event[0]=='end':
   sy,label=frames.pop();parts.insert(0,f'<rect x="8" y="{sy-23}" width="804" height="{y-sy+35}" fill="none" stroke="#6c7886" stroke-width="1.4"/>');text(22,sy,label,16,'start','bold',chars=110);y+=25
  elif event[0]=='note':
   txt=event[1];n=max(1,len(textwrap.wrap(txt,76)));parts.append(f'<rect x="50" y="{y-20}" width="720" height="{n*24+20}" fill="#f7f8fa" stroke="#a1aab5"/>')
   for j,t in enumerate(textwrap.wrap(txt,76)):text(w/2,y+j*24,t,17,chars=76)
   y+=n*24+43
  else:
   a,b,label,*reply=event;a=actors.index(a);b=actors.index(b);x1,x2=xs[a],xs[b];n=max(1,len(textwrap.wrap(label,31)));yy=y+n*23
   text((x1+x2)/2,y,label,18)
   style='stroke-dasharray="7,5"' if reply else ''
   if a==b:
    parts.append(f'<path d="M{x1},{yy} h55 v24 h-55" fill="none" stroke="#273343" stroke-width="1.7" marker-end="url(#arrow)" {style}/>');yy+=24
   else:parts.append(f'<line x1="{x1}" y1="{yy}" x2="{x2}" y2="{yy}" stroke="#273343" stroke-width="1.7" marker-end="url(#arrow)" {style}/>')
   y=yy+27
 height=y+65
 lifelines=[f'<line x1="{x}" y1="80" x2="{x}" y2="{height-20}" stroke="#9ba4af" stroke-dasharray="7,6"/>' for x in xs]
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{height}" viewBox="0 0 {w} {height}"><rect width="100%" height="100%" fill="white"/><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7" fill="none" stroke="#273343"/></marker></defs>'+''.join(lifelines+parts)+'</svg>'
 (F/(name+'.svg')).write_text(svg);fitz.open(stream=svg.encode(),filetype='svg')[0].get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save(str(F/(name+'.png')))
 (F/(name+'.json')).write_text(json.dumps(dict(actors=actors,events=events),indent=2));manifest.append(dict(file=name,title=title,type='Editable SVG and interaction JSON'))
sequence('sequence-discovery',['Customer','React UI','Discovery API','Database'],[
('Customer','React UI','Open menu / request suggestions'),('React UI','Discovery API','POST menu/suggestions or menu/basket-guide'),('Discovery API','Database','Read active menus, recipes, paid history and basket'),('Database','Discovery API','Candidate and preference evidence','reply'),('Discovery API','Discovery API','Rank; price full candidate baskets; check bounded slots'),('Discovery API','Database','Save RecommendationSession'),('Discovery API','React UI','Up to three alternatives, totals and reasons','reply'),('React UI','Discovery API','Record rendered impression / selected interaction'),('note','Suggestion telemetry is session-bound; a suggestion is not an order or reserved kitchen time.')], 'Recommendation and date-finder sequence')
sequence('sequence-basket',['Customer','React UI','Basket API','Database'],[
('Customer','React UI','Choose Add or change quantity'),('React UI','Basket API','CSRF-protected POST / PATCH'),('Basket API','Database','Verify authenticated owner, menu and allowed quantity; write'),('Database','Basket API','Saved row','reply'),('Basket API','React UI','Confirmed mutation','reply'),('React UI','Basket API','GET refreshed basket'),('Basket API','React UI','Authoritative rows and quantities','reply'),('React UI','Customer','Show quantity control and timed success popup','reply'),('note','If write succeeds but refresh fails, explain that it was saved; do not automatically repeat Add.')], 'Basket addition and response recovery sequence')
sequence('sequence-checkout',['Customer','React checkout','Order API','Database'],[
('Customer','React checkout','Choose fulfilment, requested time and payment'),('React checkout','Order API','POST orders/quote with basket version'),('Order API','Database','Read settings, accepted candidate recipes and bookings'),('Order API','React checkout','Quote / plan or explicit review request','reply'),('React checkout','Order API','POST orders/place with checkout UUID and reviewed terms'),('frame','atomic transaction'),('Order API','Database','Lock user, kitchen and relevant records; recheck availability'),('Order API','Database','Save order + item, recipe, preparation and fulfilment snapshots'),('Order API','Database','Clear accepted basket; retain unique checkout UUID'),('end',),('Order API','React checkout','Same order returned on valid repeated request','reply'),('note','No stock is deducted at checkout. A review request remains unpaid, with no reserved preparation plan.')], 'Quote and retry-safe placement sequence')
sequence('sequence-paypal',['Customer','Payment UI','Django payment','PayPal Sandbox'],[
('Customer','Payment UI','Open saved order payment'),('Payment UI','Django payment','Create order-bound provider checkout'),('Django payment','PayPal Sandbox','Server-calculated MYR amount and request identity'),('PayPal Sandbox','Django payment','Provider order identifier','reply'),('Payment UI','PayPal Sandbox','Buyer reviews and approves Sandbox payment'),('Payment UI','Django payment','Capture / recheck saved provider order'),('Django payment','PayPal Sandbox','Verify capture, status, amount and currency'),('PayPal Sandbox','Django payment','Verified provider evidence','reply'),('Django payment','Django payment','Lock order; write one PaymentEvent; mark paid'),('Django payment','Payment UI','Verified payment result','reply'),('note','A browser success callback alone cannot mark paid. Provider timeouts preserve a recoverable saved identity.')], 'Order-bound PayPal verification sequence')
sequence('sequence-replan',['Owner','Planner UI','Planning API','Database'],[
('Owner','Planner UI','Calculate plan for agreed future time'),('Planner UI','Planning API','Preview using order version and accepted / explicit current settings'),('Planning API','Database','Read accepted recipe, hours, closures and other bookings'),('Planning API','Planning API','Backward scheduling; guarded multi-day sessions'),('Planning API','Planner UI','Tasks, start/end, warnings and signed preview','reply'),('Owner','Planner UI','Review and confirm'),('frame','atomic confirm; signed preview expires in 10 minutes'),('Planner UI','Planning API','Confirm signed proposal'),('Planning API','Database','Lock kitchen / order; recompute and verify version'),('Planning API','Database','Save reviewed plan and OrderAmendment'),('end',),('Planning API','Planner UI','Confirmed plan or 409 stale-state recovery','reply')], 'Preparation preview and confirmation sequence')
sequence('sequence-fefo',['Owner','Progress API','FEFO logic','Database'],[
('Owner','Progress API','Confirm food ready for selected eligible orders'),('frame','atomic group; maximum 20 selected orders'),('Progress API','Database','Lock orders; verify versions and valid preparation'),('Progress API','FEFO logic','Deduct each not-yet-deducted accepted recipe'),('FEFO logic','Database','Lock stock union in material / expiry / receipt / ID order'),('FEFO logic','Database','Consume received, dated, unheld lots; write consumption and logs'),('note','Any shortage rolls back all selected stock and order changes; repeated ready does not deduct twice.'),('Progress API','Database','Set inventory_deducted and cooked status'),('end',),('Progress API','Owner','Actual progress saved; payment unchanged','reply')], 'Transactional FEFO and grouped progress sequence')
sequence('sequence-inventory',['Owner','Inventory UI','Inventory API','Database'],[
('Owner','Inventory UI','Choose ingredient, evidence mode and actual storage'),('Inventory UI','Inventory UI','Optionally copy matching documented material guidance'),('Inventory UI','Inventory API','Save quantity, dates, evidence and edit version'),('Inventory API','Inventory API','Validate pairs; compute earliest deadline; enforce handling hold'),('Inventory API','Database','Lock / validate record version; save batch and audit'),('Inventory API','Inventory UI','Saved native-unit stock and dated status','reply'),('note','Guidance must match actual conditions. Updating a material reference does not recalculate old batches.')], 'Batch evidence and optimistic editing sequence')
sequence('sequence-analytics',['Owner','Report UI','Report API','Database'],[
('Owner','Report UI','Select report and date range'),('Report UI','Report API','Request sales / contribution / cost evidence'),('Report API','Database','Aggregate eligible orders, snapshot prices and actual consumption'),('Database','Report API','Recorded revenue and cost evidence','reply'),('Report API','Report API','Compute known contribution; preserve missing values'),('Report API','Report UI','Charts, rows, exclusions and export scope','reply'),('note','Creation-date contribution, delivery-date demand and current recipe estimates are distinct views. Missing cost is not zero.')], 'Sales and contribution reporting sequence')
sequence('sequence-freshcast',['Owner','FreshCast UI','Forecast service','Data source'],[
('Owner','FreshCast UI','Choose kitchen / Genpact / fixed walkthrough source'),('FreshCast UI','Forecast service','Request matching source-specific plan'),('Forecast service','Data source','Read database evidence OR saved model / simulated operations'),('Data source','Forecast service','Source-labelled demand, recipes and eligible lots','reply'),('Forecast service','Forecast service','Separate known bookings; allocate dated stock; derive risk'),('Forecast service','FreshCast UI','Forecast need, expiry remainder, shortage and limitations','reply'),('Owner','FreshCast UI','Compare a hypothetical purchase / action'),('FreshCast UI','Forecast service','Run read-only scenario with same baseline'),('Forecast service','FreshCast UI','Reviewable comparison; no purchase or stock write','reply')], 'FreshCast source separation and scenario sequence')
sequence('sequence-reminders',['Scheduler','Worker endpoint','Database','SMTP'],[
('Scheduler','Worker endpoint','Authenticated periodic call (one configured scheduler)'),('Worker endpoint','Worker endpoint','Validate Bearer secret; determine configured mail readiness'),('Worker endpoint','Database','Select due owner / opted-in customer events; inspect receipts'),('frame','bounded call; at most 3 email attempts'),('Worker endpoint','Database','Lock due order; recheck time, consent, recipient and state'),('Worker endpoint','SMTP','Send eligible reminder or queued update'),('SMTP','Worker endpoint','Accepted / failed delivery attempt','reply'),('Worker endpoint','Database','Save receipt only after provider acceptance'),('end',),('Worker endpoint','Scheduler','Authenticated run totals','reply'),('note','A five-minute schedule is not a five-minute reminder. Acceptance does not prove inbox receipt; scheduling can be delayed.')], 'Authenticated, receipt-based email reminder sequence')
sequence('sequence-escrow',['Buyer wallet','Payment UI','Escrow API','Sepolia RPC'],[
('Payment UI','Escrow API','Create invoice for own unpaid order and buyer wallet'),('Escrow API','Payment UI','Fixed reference, chain, contract, parties, wei and deadline','reply'),('Buyer wallet','Sepolia RPC','Sign and broadcast funding to configured contract'),('Payment UI','Escrow API','Persist submitted transaction hash; request verification'),('Escrow API','Sepolia RPC','Read receipt, canonical block, transaction, runtime and state'),('Sepolia RPC','Escrow API','Confirmed chain evidence or pending / unavailable','reply'),('Escrow API','Escrow API','Check exact invoice; write idempotent receipt only if verified'),('Escrow API','Payment UI','Paid / pending / rejected; no automatic fulfilment','reply'),('note','Sepolia test funds only. The server never receives wallet private keys or sends cryptocurrency.')], 'Order-bound escrow verification sequence')
(F/'diagram-manifest.json').write_text(json.dumps(manifest,indent=2));print('Generated',len(manifest),'diagrams')
