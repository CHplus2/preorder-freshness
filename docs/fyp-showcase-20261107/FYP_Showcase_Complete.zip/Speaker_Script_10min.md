# FYP speaker script — provisional 10 minutes

The supplied briefing does not specify a presentation duration. Confirm the speaking and Q&A allocation with the supervisor. The times below are a rehearsal plan, not an institutional requirement.

## 1. Preorders and ingredient records, connected.
00:00–00:25

Good morning. I am Christopher Hansen. My project is a web-based preorder and freshness management system for home-based food entrepreneurs. The case study is Wrap and Bowl Kuch, a small food business in Kuching. I will show how a customer order connects to the kitchen's ingredient, packaging and reporting records.

## 2. The gap is the connection between tasks.
00:25–01:20

Chapter 1 identifies several related gaps. Messaging-based orders rely on the seller to track dates and details. My Chapter 2 comparison describes shorter advance-ordering windows in the selected delivery platforms. Those are findings of the review, rather than a claim that every current service has the same policy. The report also discusses Malaysian food-poisoning cases as motivation for better ingredient management. This does not mean every incident involved a home business, or that expiry software prevents poisoning. Finally, a home kitchen may want its own storefront and connected decision support. GrabFood and foodpanda already provide analytics; the gap here is integrating the functions needed by this case study.

## 3. The five original objectives
01:20–02:00

The five objectives remain unchanged. They concern flexible date-based preordering, ingredient shelf life and storage duration, a personalised single-vendor storefront, sales analytics, and menu recommendations. The implementation provides these functions. However, the final objective includes reduced decision fatigue and improved conversion. Those effects require user or operational evidence; I do not claim they have been proved by software tests alone.

## 4. Client feedback shaped the implementation.
02:00–02:45

I used an iterative development approach and revised the system after client feedback. The client preferred a simpler ordering routine, with name and phone details, morning handover, packaging stock, payment receipt uploads and order printing. Detailed preparation planning was removed from the normal workflow because it did not fit her needs. Passkeys allow customer access without a separate memorised website password. These meetings informed requirements, but they have not been reported as a completed formal acceptance study.

## 5. One order connects the records.
02:45–03:35

React presents the interface, Django applies the rules, and PostgreSQL stores the records through Supabase. The important mechanism is the connection. The server calculates the order total and checks the date, ingredients and packaging. If a requirement is short, the order is not partly saved with only some stock deducted. When placement succeeds, the accepted menu names, prices and requirements are preserved. This allows the owner to edit a current menu without rewriting an earlier customer's order. Payment verification and food receipt remain separate actions.

## 6. Feature story 1: a practical preorder journey.
03:35–04:25

The first feature story is the customer journey. Customers browse one kitchen's menu and can request suggestions for a date, quantity and whole-order budget. They may allow a mix or compare single-menu alternatives. Checkout collects fulfilment details once and displays the area fee and complete total. Delivery supports the configured bank-payment evidence or cash. Collection requires QR payment evidence. A receipt upload is not automatic bank confirmation. The owner still checks it. This gives a clear ordering process without claiming an integration with a bank or GrabExpress.

## 7. Feature story 2: dates guide usable stock.
04:25–05:10

The second story is ingredient monitoring. Different batches can have different received dates and evidence. The owner can use a printed deadline or a documented duration from manufacture or receipt. Earlier opening, thawing or printed limits take priority. Held and past-deadline stock is excluded from usable quantities. The rules are based on recorded dates, rather than randomly generated freshness scores. They support stock planning, but the application cannot measure contamination or verify how the food was physically handled.

## 8. Two-minute application walkthrough
05:10–07:10

I will now show the connected workflow. The recording uses the current application running locally with example records. No bank transfer, live customer order or courier booking is involved. If the live walkthrough fails, I will switch once to the recording, then use the screenshot sequence if needed. [Run the two-minute walkthrough. During live delivery, use the separate demo narration.]

## 9. What the testing supports
07:10–08:10

Testing checked whether the implemented rules behaved as expected. Examples include the morning time boundaries, a complete order total, one-time ingredient and packaging deductions, and rejection when stock is insufficient. Browser checks exercised the visible flow as well. These are automated software checks; they are not student survey answers or a signed client evaluation. Some environment-dependent checks were skipped, and they are not counted as passes. The client follow-up and student questionnaire are prepared. Their actual responses will be used to assess clarity, practicality and reported choice effort.

## 10. The limits are part of the result.
08:10–09:10

There are practical limits. The owner must maintain truthful stock dates, quantities and costs. Date indicators cannot guarantee food safety. The website cannot know that a bank transfer settled or a rider delivered food without reliable external evidence, so those checks remain manual. Passkeys reduce memorised credentials but introduce device and recovery considerations. The development records are examples, not genuine client sales. The next step is formal user evaluation and validation of the estimated recipes, packaging and operating details with the owner. Future integrations should be considered only when there is a clear need and suitable access.

## 11. A simpler workflow, with connected records.
09:10–10:00

The project demonstrates how these functions can work together for a home kitchen. Its contribution is the connected workflow: customers select an offered date and clear total, while accepted orders update ingredient and packaging records and remain available for reporting. Client feedback helped remove unnecessary preparation-planning steps from the normal routine. The five original objectives remain the basis of the work. Functional testing supports the implemented behaviour, while client and student evidence is still needed to judge the user benefits. Thank you. I am ready for your questions.
