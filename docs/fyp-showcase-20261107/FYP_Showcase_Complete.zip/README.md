# FYP presentation and showcase package

Start with Gamma_10min_Paste.txt or the editable PPTX, then read Presentation_and_Demo_Guide.md.
The ten-minute allocation is provisional. A1 portrait poster size is confirmed.

The package includes an A1 PDF/PNG/editable PPTX poster, slide deck and script, narrated/silent two-minute edited walkthrough, captions, separate draft synthetic voice, raw source clips, and a screenshot fallback.

The five objectives are unchanged. Formal client/student evaluation results are pending. The walkthrough uses current local application screens and example records, not a bank transfer or a live customer order. It combines screen recordings with held captures for readable narration. No third-party editor or Gamma account was connected.

Use the poster PDF at actual A1 size for printing. The poster QR opens the public menu, not a payment endpoint. No institutional logo has been invented.
