# Five-minute version for a short showcase or hackathon

This is an alternative rehearsal format, not the confirmed FYP time limit.

0:00–0:25 — Title and client context.
0:25–1:10 — Problem: disconnected preorder dates, ingredient records and business presentation. Describe the platform windows as findings from the report review, not universal current policy.
1:10–1:40 — Solution and mechanism: date/price/stock validation, then one accepted order with ingredient and packaging deductions.
1:40–2:40 — Two feature stories: practical customer checkout and owner date-based stock monitoring. Briefly locate sales and recommendations within the five objectives.
2:40–4:10 — Ninety-second demonstration. Use the shorter live steps in the demo playbook; do not rush through every management page.
4:10–4:40 — Testing and limits. Automated checks are not user results. No food-safety or conversion improvement is claimed.
4:40–5:00 — Conclude with the contribution and next evaluation step.

For a longer FYP talk, add methodology, design decisions, objective-linked tests and discussion. Do not fill extra minutes with a catalogue of buttons. A business plan belongs in a backup answer unless the assessment specifically asks for it.
