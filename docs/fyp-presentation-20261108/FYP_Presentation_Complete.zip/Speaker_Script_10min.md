# Ten-minute FYP presentation script

Timing is provisional; the lecturer has not confirmed the limit. The two-minute demo is the last content section. Q&A is not timed here.

## Slide 1: Preorder & Freshness Management — 20 seconds

Good morning. I am Christopher Hansen. My FYP is a web-based preorder and freshness management system for home-based food entrepreneurs, developed with Wrap & Bowl Kuch in Kuching. I will explain the problem, the connected workflow, the key functions and testing, then finish with a two-minute demonstration.

## Slide 2: The problem: separate tasks and records — 50 seconds

The problem statement follows Chapters 1 and 2. Messaging orders require separate recording and coordination. The review describes limits in advance-ordering support and a business’s independent branding. Malaysian food-poisoning reports motivate better ingredient records, but dates do not detect contamination. I am not claiming that every home kitchen is unsafe or that current platforms all have identical policies.

## Slide 3: The five original objectives — 40 seconds

The objectives are unchanged: date-based preordering, recorded ingredient shelf life, one business’s storefront, sales information and menu recommendations. The software implements the functions. Reduced decision fatigue and improved paid conversion need user or operational evidence; a software test alone cannot prove those outcomes.

## Slide 4: The solution was shaped by the client — 40 seconds

I developed the system in stages, checked the functions, and revised them following client meetings. The client asked for packaging records, automatic ingredient deductions, simpler customer details, morning delivery and payment receipt uploads. Detailed preparation planning did not fit her routine, so it is not required for normal ordering. These meetings informed requirements; do not describe them as a scored formal acceptance study.

## Slide 5: How one preorder connects the records — 50 seconds

React presents the interface, Django validates the rules and Supabase PostgreSQL stores the records. The server checks the actual basket price, offered date, area fee, ingredients and packaging. Saving the order and deducting stock are one transaction. Accepted item names, prices and requirements are retained as order snapshots. Checking payment evidence and confirming actual food receipt remain separate owner actions.

## Slide 6: Browse one kitchen and compare choices — 45 seconds

The storefront presents one business rather than a marketplace of competing sellers. Menu cards explain what a portion or box contains. Customers may browse directly or request suggestions for their date, quantity and budget. The finder compares complete options; it does not treat a three-unit total as the price of one unit. Recommendation calculations do not by themselves show that decision fatigue was reduced.

## Slide 7: Choose a date and see the full total — 50 seconds

An account uses name and phone details with a saved passkey, avoiding a separate memorised website password. A phone number alone is not authentication. Checkout guides the customer to offered dates, a morning time and an area-based delivery fee. QR or bank-transfer evidence is uploaded for manual review. Delivery permits cash where configured; collection requires QR payment evidence. Uploading a picture does not mark the order paid.

## Slide 8: Recorded dates guide usable stock — 50 seconds

The owner records a batch received date, actual storage and either a printed deadline or documented storage life. The earliest relevant deadline, including opening or thawing where recorded, guides allocation. Held or past-deadline batches are excluded. In the captured local order, chicken decreased by 130 grams and one salad bowl was deducted. These are recorded-date rules, not a measurement of physical safety.

## Slide 9: Manage the order without confusing payment — 40 seconds

Payment confirmation and food receipt mean different things. The owner checks the transfer or collected cash before recording payment, and marks the food received only after actual delivery or collection. Order queues, daily summaries and printable slips include the accepted order details. A courier API is not integrated, so the site does not automatically assert delivery merely because the planned time has passed.

## Slide 10: Use sales information with its cost limits — 40 seconds

The daily order summary helps the owner prepare and hand over orders for a date. Sales reports apply the stated payment and receipt rules. Contribution considers recorded ingredient and packaging costs where available; it is not automatically net profit. Missing costs are shown as incomplete rather than converted to zero. The local history forecast is separate from the FreshCast Genpact demonstration and is not evidence of real-business demand accuracy.

## Slide 11: What has been tested—and what needs feedback — 30 seconds

These are development and browser checks, not survey answers. The captured order-to-stock journey completed with no recorded page error. Some environment-dependent regression checks are skipped, and they are not passes. BEFORE FINAL PRESENTATION: replace or extend this slide with actual client and student evaluation findings once collected. State real participant numbers, tasks, findings and changes; do not invent scores.

## Slide 12: One connected workflow for a home kitchen — 25 seconds

The contribution is a connected workflow adapted to the client: customers choose food and an offered date while accepted orders update ingredient and packaging records for owner follow-up and reporting. These functions have practical limits and still need formal user feedback. I will finish with the recorded demonstration, then take questions.

## Slide 13: Demo: customer order to kitchen records — 120 seconds

Play the embedded two-minute client-photo video. It uses the actual application running locally with supplied client photographs, separate example accounts/orders/stock and a virtual passkey. No real bank transfer, live customer order or courier booking was made. Click the video in PowerPoint; if the editor does not support embedded playback, open Demo_120s_Client_Photos_1080p.mp4 from the same folder. If video fails, use Screenshot_Fallback.pdf. End with questions after the demo.

## Slide 14: Questions — 0 seconds

Thank you. Use the separate design backup slides or the full report if the panel asks about the data model, access control, stock allocation or evaluation limits.

